﻿namespace LRSV_pim
{
    partial class Administrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            button1 = new Button();
            button2 = new Button();
            dateTimePicker1 = new DateTimePicker();
            menuStrip1 = new MenuStrip();
            toolStripTextBox1 = new ToolStripTextBox();
            menuPrincipalToolStripMenuItem = new ToolStripMenuItem();
            painelDoADMToolStripMenuItem = new ToolStripMenuItem();
            label1 = new Label();
            processosToolStripMenuItem = new ToolStripMenuItem();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            button6 = new Button();
            button7 = new Button();
            button8 = new Button();
            button9 = new Button();
            button10 = new Button();
            button11 = new Button();
            menuStrip1.SuspendLayout();
            SuspendLayout();
            // 
            // button1
            // 
            button1.Location = new Point(12, 85);
            button1.Name = "button1";
            button1.Size = new Size(128, 51);
            button1.TabIndex = 1;
            button1.Text = "Admitir empregado";
            button1.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Location = new Point(146, 85);
            button2.Name = "button2";
            button2.Size = new Size(128, 51);
            button2.TabIndex = 2;
            button2.Text = "Alterar dados pessoais";
            button2.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(458, 398);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(330, 27);
            dateTimePicker1.TabIndex = 3;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { toolStripTextBox1, menuPrincipalToolStripMenuItem, painelDoADMToolStripMenuItem, processosToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 31);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // toolStripTextBox1
            // 
            toolStripTextBox1.Name = "toolStripTextBox1";
            toolStripTextBox1.Size = new Size(100, 27);
            toolStripTextBox1.Text = "Home";
            toolStripTextBox1.Click += toolStripTextBox1_Click;
            // 
            // menuPrincipalToolStripMenuItem
            // 
            menuPrincipalToolStripMenuItem.Name = "menuPrincipalToolStripMenuItem";
            menuPrincipalToolStripMenuItem.Size = new Size(121, 27);
            menuPrincipalToolStripMenuItem.Text = "Menu Principal";
            // 
            // painelDoADMToolStripMenuItem
            // 
            painelDoADMToolStripMenuItem.Name = "painelDoADMToolStripMenuItem";
            painelDoADMToolStripMenuItem.Size = new Size(122, 27);
            painelDoADMToolStripMenuItem.Text = "Painel do ADM";
            // 
            // label1
            // 
            label1.AllowDrop = true;
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Times New Roman", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(0, 44);
            label1.Name = "label1";
            label1.Size = new Size(123, 21);
            label1.TabIndex = 5;
            label1.Text = "Painel do ADM";
            label1.Click += label1_Click_1;
            // 
            // processosToolStripMenuItem
            // 
            processosToolStripMenuItem.Name = "processosToolStripMenuItem";
            processosToolStripMenuItem.Size = new Size(87, 27);
            processosToolStripMenuItem.Text = "Processos";
            // 
            // button3
            // 
            button3.Location = new Point(280, 85);
            button3.Name = "button3";
            button3.Size = new Size(128, 51);
            button3.TabIndex = 6;
            button3.Text = "Transmitir Arquivos";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Location = new Point(414, 85);
            button4.Name = "button4";
            button4.Size = new Size(128, 51);
            button4.TabIndex = 7;
            button4.Text = "Alterar função";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Location = new Point(548, 85);
            button5.Name = "button5";
            button5.Size = new Size(128, 51);
            button5.TabIndex = 8;
            button5.Text = "Alterar salário";
            button5.UseVisualStyleBackColor = true;
            // 
            // button6
            // 
            button6.Location = new Point(12, 158);
            button6.Name = "button6";
            button6.RightToLeft = RightToLeft.No;
            button6.Size = new Size(128, 51);
            button6.TabIndex = 9;
            button6.Text = "Alterar lotação";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Location = new Point(146, 158);
            button7.Name = "button7";
            button7.Size = new Size(128, 51);
            button7.TabIndex = 10;
            button7.Text = "Férias";
            button7.UseVisualStyleBackColor = true;
            // 
            // button8
            // 
            button8.Location = new Point(280, 159);
            button8.Name = "button8";
            button8.Size = new Size(128, 51);
            button8.TabIndex = 11;
            button8.Text = "Pensão alimentícia";
            button8.UseVisualStyleBackColor = true;
            // 
            // button9
            // 
            button9.Location = new Point(414, 158);
            button9.Name = "button9";
            button9.Size = new Size(128, 51);
            button9.TabIndex = 12;
            button9.Text = "Alterar horário";
            button9.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Location = new Point(548, 159);
            button10.Name = "button10";
            button10.Size = new Size(128, 51);
            button10.TabIndex = 13;
            button10.Text = "Pagamentos adicionais";
            button10.UseVisualStyleBackColor = true;
            // 
            // button11
            // 
            button11.Location = new Point(12, 228);
            button11.Name = "button11";
            button11.Size = new Size(128, 51);
            button11.TabIndex = 14;
            button11.Text = "Cadastrar falta";
            button11.UseVisualStyleBackColor = true;
            // 
            // Administrador
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button11);
            Controls.Add(button10);
            Controls.Add(button9);
            Controls.Add(button8);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(label1);
            Controls.Add(dateTimePicker1);
            Controls.Add(button2);
            Controls.Add(button1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Administrador";
            Text = "Administrador - LRSV Software Factory";
            Load += Administrador_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private Button button1;
        private Button button2;
        private DateTimePicker dateTimePicker1;
        private MenuStrip menuStrip1;
        private ToolStripTextBox toolStripTextBox1;
        private ToolStripMenuItem menuPrincipalToolStripMenuItem;
        private ToolStripMenuItem painelDoADMToolStripMenuItem;
        private Label label1;
        private ToolStripMenuItem processosToolStripMenuItem;
        private Button button3;
        private Button button4;
        private Button button5;
        private Button button6;
        private Button button7;
        private Button button8;
        private Button button9;
        private Button button10;
        private Button button11;
    }
}