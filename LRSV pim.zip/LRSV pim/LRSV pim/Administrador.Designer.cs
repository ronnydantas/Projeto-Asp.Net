﻿namespace LRSV_pim
{
    partial class Administrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dateTimePicker1 = new DateTimePicker();
            menuStrip1 = new MenuStrip();
            toolStripTextBox1 = new ToolStripMenuItem();
            menuPrincipalToolStripMenuItem = new ToolStripMenuItem();
            painelDoADMToolStripMenuItem = new ToolStripMenuItem();
            processosToolStripMenuItem = new ToolStripMenuItem();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button7 = new Button();
            button8 = new Button();
            button10 = new Button();
            groupBox1 = new GroupBox();
            menuStrip1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(458, 398);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(330, 27);
            dateTimePicker1.TabIndex = 3;
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { toolStripTextBox1, menuPrincipalToolStripMenuItem, painelDoADMToolStripMenuItem, processosToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 26);
            menuStrip1.TabIndex = 4;
            menuStrip1.Text = "menuStrip1";
            menuStrip1.ItemClicked += menuStrip1_ItemClicked;
            // 
            // toolStripTextBox1
            // 
            toolStripTextBox1.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            toolStripTextBox1.Name = "toolStripTextBox1";
            toolStripTextBox1.Size = new Size(67, 22);
            toolStripTextBox1.Text = "Home";
            toolStripTextBox1.Click += toolStripTextBox1_Click;
            // 
            // menuPrincipalToolStripMenuItem
            // 
            menuPrincipalToolStripMenuItem.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            menuPrincipalToolStripMenuItem.Name = "menuPrincipalToolStripMenuItem";
            menuPrincipalToolStripMenuItem.Size = new Size(126, 22);
            menuPrincipalToolStripMenuItem.Text = "Menu Principal";
            // 
            // painelDoADMToolStripMenuItem
            // 
            painelDoADMToolStripMenuItem.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            painelDoADMToolStripMenuItem.Name = "painelDoADMToolStripMenuItem";
            painelDoADMToolStripMenuItem.Size = new Size(127, 22);
            painelDoADMToolStripMenuItem.Text = "Painel do ADM";
            // 
            // processosToolStripMenuItem
            // 
            processosToolStripMenuItem.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            processosToolStripMenuItem.Name = "processosToolStripMenuItem";
            processosToolStripMenuItem.Size = new Size(98, 22);
            processosToolStripMenuItem.Text = "Processos";
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(32, 36);
            button1.Name = "button1";
            button1.Size = new Size(195, 51);
            button1.TabIndex = 15;
            button1.Text = "Admitir empregado";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(435, 117);
            button2.Name = "button2";
            button2.Size = new Size(189, 51);
            button2.TabIndex = 16;
            button2.Text = "Alterar dados de colaboradores";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(435, 36);
            button3.Name = "button3";
            button3.Size = new Size(189, 51);
            button3.TabIndex = 17;
            button3.Text = "Transmitir Arquivos";
            button3.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(267, 117);
            button7.Name = "button7";
            button7.Size = new Size(128, 51);
            button7.TabIndex = 21;
            button7.Text = "Férias";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Location = new Point(233, 36);
            button8.Name = "button8";
            button8.Size = new Size(191, 51);
            button8.TabIndex = 22;
            button8.Text = "Pensão alimentícia";
            button8.UseVisualStyleBackColor = true;
            // 
            // button10
            // 
            button10.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button10.Location = new Point(32, 117);
            button10.Name = "button10";
            button10.Size = new Size(195, 51);
            button10.TabIndex = 24;
            button10.Text = "Pagamentos adicionais";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button10);
            groupBox1.Controls.Add(button8);
            groupBox1.Controls.Add(button7);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(23, 50);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(707, 222);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Painel do ADM";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // Administrador
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(dateTimePicker1);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Administrador";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Administrador - LRSV Software Factory";
            Load += Administrador_Load;
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DateTimePicker dateTimePicker1;
        private MenuStrip menuStrip1;
        private ToolStripMenuItem menuPrincipalToolStripMenuItem;
        private ToolStripMenuItem painelDoADMToolStripMenuItem;
        private ToolStripMenuItem processosToolStripMenuItem;
        private ToolStripMenuItem toolStripTextBox1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button7;
        private Button button8;
        private Button button10;
        private GroupBox groupBox1;
    }
}