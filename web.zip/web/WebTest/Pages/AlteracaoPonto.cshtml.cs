using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebTest.Pages
{
    public class AlteracaoPontoModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
