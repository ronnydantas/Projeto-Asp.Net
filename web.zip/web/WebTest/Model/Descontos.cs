﻿namespace WebTest.Model
{
    public class Descontos
    {
        public int Id { get; set; }
        public int Inss { get; set; }
    }
}
