﻿namespace LRSV_pim
{
    partial class PagFunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(PagFunc));
            panel1 = new Panel();
            button8 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            label2 = new Label();
            panel5 = new Panel();
            pictureBox5 = new PictureBox();
            label5 = new Label();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            panel4 = new Panel();
            label3 = new Label();
            comboBox1 = new ComboBox();
            label4 = new Label();
            panel3 = new Panel();
            label22 = new Label();
            label21 = new Label();
            label20 = new Label();
            label19 = new Label();
            label18 = new Label();
            label17 = new Label();
            label16 = new Label();
            label15 = new Label();
            label14 = new Label();
            label13 = new Label();
            label11 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            label10 = new Label();
            panel6 = new Panel();
            label12 = new Label();
            linkLabel1 = new LinkLabel();
            button7 = new Button();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel4.SuspendLayout();
            panel3.SuspendLayout();
            panel6.SuspendLayout();
            SuspendLayout();
            // 
            // panel1
            // 
            panel1.BackColor = Color.SteelBlue;
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 553);
            panel1.TabIndex = 4;
            // 
            // button8
            // 
            button8.BackColor = Color.SteelBlue;
            button8.Dock = DockStyle.Top;
            button8.FlatAppearance.BorderColor = Color.SteelBlue;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.MouseDownBackColor = Color.Gray;
            button8.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Image = (Image)resources.GetObject("button8.Image");
            button8.ImageAlign = ContentAlignment.MiddleLeft;
            button8.Location = new Point(0, 468);
            button8.Margin = new Padding(4);
            button8.Name = "button8";
            button8.Size = new Size(250, 66);
            button8.TabIndex = 6;
            button8.Text = "Sair";
            button8.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.SteelBlue;
            button5.Dock = DockStyle.Top;
            button5.FlatAppearance.BorderColor = Color.SteelBlue;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseDownBackColor = Color.Gray;
            button5.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(0, 402);
            button5.Margin = new Padding(4);
            button5.Name = "button5";
            button5.Size = new Size(250, 66);
            button5.TabIndex = 5;
            button5.Text = "Chamados";
            button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.SteelBlue;
            button4.Dock = DockStyle.Top;
            button4.FlatAppearance.BorderColor = Color.SteelBlue;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseDownBackColor = Color.Gray;
            button4.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(0, 336);
            button4.Margin = new Padding(4);
            button4.Name = "button4";
            button4.Size = new Size(250, 66);
            button4.TabIndex = 4;
            button4.Text = "Férias";
            button4.UseVisualStyleBackColor = false;
            // 
            // button3
            // 
            button3.BackColor = Color.SteelBlue;
            button3.Dock = DockStyle.Top;
            button3.FlatAppearance.BorderColor = Color.SteelBlue;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.Gray;
            button3.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(0, 270);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.Size = new Size(250, 66);
            button3.TabIndex = 3;
            button3.Text = "Pagamento";
            button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.SteelBlue;
            button2.Dock = DockStyle.Top;
            button2.FlatAppearance.BorderColor = Color.SteelBlue;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseDownBackColor = Color.Gray;
            button2.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(0, 204);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(250, 66);
            button2.TabIndex = 2;
            button2.Text = "Ponto";
            button2.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.SteelBlue;
            button1.Dock = DockStyle.Top;
            button1.FlatAppearance.BorderColor = Color.SteelBlue;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.Gray;
            button1.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(0, 138);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(250, 66);
            button1.TabIndex = 1;
            button1.Text = "Home";
            button1.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightSteelBlue;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4);
            panel2.Name = "panel2";
            panel2.Size = new Size(250, 138);
            panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(58, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(131, 134);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(20, 34);
            label2.Name = "label2";
            label2.Size = new Size(147, 28);
            label2.TabIndex = 1;
            label2.Text = "Fábio Assis.";
            // 
            // panel5
            // 
            panel5.BackColor = Color.SteelBlue;
            panel5.Controls.Add(pictureBox5);
            panel5.Controls.Add(label5);
            panel5.Controls.Add(pictureBox2);
            panel5.Controls.Add(label2);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(250, 47);
            panel5.Name = "panel5";
            panel5.Size = new Size(732, 91);
            panel5.TabIndex = 7;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(650, 16);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(125, 76);
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(518, 36);
            label5.Name = "label5";
            label5.Size = new Size(126, 27);
            label5.TabIndex = 5;
            label5.Text = "Pagamento";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(892, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(85, 62);
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(208, 9);
            label1.Name = "label1";
            label1.Size = new Size(326, 28);
            label1.TabIndex = 0;
            label1.Text = "LRSV - Software Factory";
            // 
            // panel4
            // 
            panel4.BackColor = Color.LightSteelBlue;
            panel4.Controls.Add(label1);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(250, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(732, 47);
            panel4.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(381, 159);
            label3.Name = "label3";
            label3.Size = new Size(484, 25);
            label3.TabIndex = 8;
            label3.Text = "Escolha o mês que deseja consultar o holerite:";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Janeiro", "Fevereiro", "Março", "Abril", "Maio", "Junho", "Julho", "Agosto", "Setembro", "Outubro", "Novembro", "Dezembro" });
            comboBox1.Location = new Point(482, 204);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(171, 28);
            comboBox1.TabIndex = 9;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(659, 204);
            label4.Name = "label4";
            label4.Size = new Size(95, 25);
            label4.TabIndex = 10;
            label4.Text = "de 2023";
            // 
            // panel3
            // 
            panel3.BackColor = SystemColors.AppWorkspace;
            panel3.Controls.Add(label22);
            panel3.Controls.Add(label21);
            panel3.Controls.Add(label20);
            panel3.Controls.Add(label19);
            panel3.Controls.Add(label18);
            panel3.Controls.Add(label17);
            panel3.Controls.Add(label16);
            panel3.Controls.Add(label15);
            panel3.Controls.Add(label14);
            panel3.Controls.Add(label13);
            panel3.Controls.Add(label11);
            panel3.Controls.Add(label6);
            panel3.Controls.Add(label7);
            panel3.Controls.Add(label8);
            panel3.Controls.Add(label9);
            panel3.Controls.Add(label10);
            panel3.Controls.Add(panel6);
            panel3.Location = new Point(300, 253);
            panel3.Margin = new Padding(3, 4, 3, 4);
            panel3.Name = "panel3";
            panel3.Size = new Size(367, 281);
            panel3.TabIndex = 69;
            // 
            // label22
            // 
            label22.AutoSize = true;
            label22.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label22.ForeColor = SystemColors.Menu;
            label22.Location = new Point(144, 242);
            label22.Name = "label22";
            label22.Size = new Size(88, 18);
            label22.TabIndex = 76;
            label22.Text = "R$ 200,00";
            // 
            // label21
            // 
            label21.AutoSize = true;
            label21.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label21.ForeColor = SystemColors.Menu;
            label21.Location = new Point(125, 213);
            label21.Name = "label21";
            label21.Size = new Size(88, 18);
            label21.TabIndex = 75;
            label21.Text = "R$ 154,60";
            // 
            // label20
            // 
            label20.AutoSize = true;
            label20.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label20.ForeColor = SystemColors.Menu;
            label20.Location = new Point(133, 187);
            label20.Name = "label20";
            label20.Size = new Size(88, 18);
            label20.TabIndex = 74;
            label20.Text = "R$ 115,40";
            // 
            // label19
            // 
            label19.AutoSize = true;
            label19.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label19.ForeColor = SystemColors.Menu;
            label19.Location = new Point(133, 162);
            label19.Name = "label19";
            label19.Size = new Size(88, 18);
            label19.TabIndex = 73;
            label19.Text = "R$ 188,70";
            // 
            // label18
            // 
            label18.AutoSize = true;
            label18.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label18.ForeColor = SystemColors.Menu;
            label18.Location = new Point(67, 139);
            label18.Name = "label18";
            label18.Size = new Size(88, 18);
            label18.TabIndex = 72;
            label18.Text = "R$ 145,20";
            // 
            // label17
            // 
            label17.AutoSize = true;
            label17.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label17.ForeColor = SystemColors.Menu;
            label17.Location = new Point(110, 77);
            label17.Name = "label17";
            label17.Size = new Size(103, 18);
            label17.TabIndex = 71;
            label17.Text = "R$ 4.450,00";
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            label16.ForeColor = SystemColors.Menu;
            label16.Location = new Point(161, 49);
            label16.Name = "label16";
            label16.Size = new Size(102, 18);
            label16.TabIndex = 70;
            label16.Text = "05/10/2023";
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(14, 141);
            label15.Name = "label15";
            label15.Size = new Size(45, 16);
            label15.TabIndex = 11;
            label15.Text = "INSS:";
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(14, 244);
            label14.Name = "label14";
            label14.Size = new Size(124, 16);
            label14.TabIndex = 10;
            label14.Text = "Vale alimentação:";
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(14, 215);
            label13.Name = "label13";
            label13.Size = new Size(98, 16);
            label13.TabIndex = 9;
            label13.Text = "Vale refeição:";
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(11, 189);
            label11.Name = "label11";
            label11.Size = new Size(114, 16);
            label11.TabIndex = 8;
            label11.Text = "Vale transporte:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(11, 49);
            label6.Name = "label6";
            label6.Size = new Size(144, 16);
            label6.TabIndex = 3;
            label6.Text = "Data De Pagamento:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(14, 164);
            label7.Name = "label7";
            label7.Size = new Size(113, 16);
            label7.TabIndex = 4;
            label7.Text = "Plano de saúde:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(11, 77);
            label8.Name = "label8";
            label8.Size = new Size(93, 16);
            label8.TabIndex = 2;
            label8.Text = "Salário Base:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label9.Location = new Point(11, 114);
            label9.Name = "label9";
            label9.Size = new Size(108, 20);
            label9.TabIndex = 5;
            label9.Text = "Descontos";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Verdana", 11.25F, FontStyle.Bold, GraphicsUnit.Point);
            label10.Location = new Point(14, 157);
            label10.Name = "label10";
            label10.Size = new Size(0, 23);
            label10.TabIndex = 1;
            // 
            // panel6
            // 
            panel6.BackColor = SystemColors.ButtonFace;
            panel6.BorderStyle = BorderStyle.FixedSingle;
            panel6.Controls.Add(label12);
            panel6.Location = new Point(0, 0);
            panel6.Margin = new Padding(3, 4, 3, 4);
            panel6.Name = "panel6";
            panel6.Size = new Size(367, 45);
            panel6.TabIndex = 0;
            panel6.Paint += panel6_Paint;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label12.Location = new Point(10, 7);
            label12.Name = "label12";
            label12.Size = new Size(92, 20);
            label12.TabIndex = 0;
            label12.Text = "Detalhes";
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(727, 392);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(206, 20);
            linkLabel1.TabIndex = 70;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Baixar holerite em pdf.";
            // 
            // button7
            // 
            button7.BackColor = Color.LightSteelBlue;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(883, 505);
            button7.Name = "button7";
            button7.Size = new Size(75, 29);
            button7.TabIndex = 71;
            button7.Text = "Voltar";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // PagFunc
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 553);
            Controls.Add(button7);
            Controls.Add(linkLabel1);
            Controls.Add(panel3);
            Controls.Add(label4);
            Controls.Add(comboBox1);
            Controls.Add(label3);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Name = "PagFunc";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pagamentos";
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel3.ResumeLayout(false);
            panel3.PerformLayout();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Panel panel1;
        private Button button8;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Label label2;
        private Panel panel5;
        private PictureBox pictureBox5;
        private Label label5;
        private PictureBox pictureBox2;
        private Label label1;
        private Panel panel4;
        private Label label3;
        private ComboBox comboBox1;
        private Label label4;
        private Panel panel3;
        private Label label11;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private Label label10;
        private Panel panel6;
        private Label label12;
        private Label label15;
        private Label label14;
        private Label label13;
        private Label label21;
        private Label label20;
        private Label label19;
        private Label label18;
        private Label label17;
        private Label label16;
        private Label label22;
        private LinkLabel linkLabel1;
        private Button button7;
    }
}