﻿using System;
using System.Collections.Generic;
using System.ComponentModel;
using System.Data;
using System.Drawing;
using System.Linq;
using System.Text;
using System.Threading.Tasks;
using System.Windows.Forms;

namespace LRSV_pim
{
    public partial class Administrador : Form
    {
        public Administrador()
        {
            InitializeComponent();
        }

        private void label1_Click(object sender, EventArgs e)
        {

        }

        private void toolStripTextBox1_Click(object sender, EventArgs e)
        {

        }

        private void menuStrip1_ItemClicked(object sender, ToolStripItemClickedEventArgs e)
        {

        }

        private void Administrador_Load(object sender, EventArgs e)
        {

        }

        private void pictureBox1_Click(object sender, EventArgs e)
        {

        }

        private void label1_Click_1(object sender, EventArgs e)
        {

        }

        private void label2_Click(object sender, EventArgs e)
        {

        }

        private void button11_Click(object sender, EventArgs e)
        {

        }

        private void button6_Click(object sender, EventArgs e)
        {
        }

        private void button1_Click(object sender, EventArgs e)
        {
            AddEmpregado addEmpregado = new AddEmpregado();
            addEmpregado.ShowDialog();
        }

        private void button2_Click(object sender, EventArgs e)
        {
            AltDados altDados = new AltDados();
            altDados.ShowDialog();
        }

        private void groupBox1_Enter(object sender, EventArgs e)
        {

        }

        private void button7_Click(object sender, EventArgs e)
        {
            CadastroDeFerias cadastroDeFerias = new CadastroDeFerias();
            cadastroDeFerias.ShowDialog();
        }

        private void button10_Click(object sender, EventArgs e)
        {
            PagAdc pagAdc = new PagAdc();
            pagAdc.ShowDialog();
        }

        private void button4_Click(object sender, EventArgs e)
        {
            AltEspPonto altEspPonto = new AltEspPonto();
            altEspPonto.ShowDialog();
        }

        private void button8_Click(object sender, EventArgs e)
        {
            IncBeneficios incBeneficios = new IncBeneficios();
            incBeneficios.ShowDialog();
        }

        private void button3_Click(object sender, EventArgs e)
        {
            TransmitirArq transmitirArq = new TransmitirArq();
            transmitirArq.ShowDialog();
        }

        private void button9_Click(object sender, EventArgs e)
        {
            Login login = new Login();
            login.ShowDialog();
        }

        private void button5_Click(object sender, EventArgs e)
        {
            HoleriteAdm holeriteAdm = new HoleriteAdm();
            holeriteAdm.ShowDialog();
        }

        private void button6_Click_1(object sender, EventArgs e)
        {
            RelatorioAdm relatorioAdm = new RelatorioAdm();
            relatorioAdm.ShowDialog();
        }

        private void processosToolStripMenuItem_Click(object sender, EventArgs e)
        {

        }

        private void chamadosEmAbertoToolStripMenuItem_Click(object sender, EventArgs e)
        {
            ProcessosAdm processosAdm = new ProcessosAdm();
            processosAdm.ShowDialog();
        }

        private void button11_Click_1(object sender, EventArgs e)
        {
            ProcessosAdm processosAdm1 = new ProcessosAdm();
            processosAdm1.ShowDialog();
        }

        private void button12_Click(object sender, EventArgs e)
        {
            Rescisao rescisao = new Rescisao();
            rescisao.ShowDialog();
        }
    }
}
