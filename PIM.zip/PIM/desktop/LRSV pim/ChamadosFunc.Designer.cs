﻿namespace LRSV_pim
{
    partial class ChamadosFunc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(ChamadosFunc));
            button8 = new Button();
            button5 = new Button();
            button4 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            panel1 = new Panel();
            button3 = new Button();
            button2 = new Button();
            label2 = new Label();
            panel5 = new Panel();
            pictureBox5 = new PictureBox();
            label5 = new Label();
            pictureBox2 = new PictureBox();
            label1 = new Label();
            panel4 = new Panel();
            label3 = new Label();
            groupBox1 = new GroupBox();
            comboBox2 = new ComboBox();
            comboBox1 = new ComboBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            textBox1 = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            label6 = new Label();
            label4 = new Label();
            button6 = new Button();
            button7 = new Button();
            linkLabel1 = new LinkLabel();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            panel1.SuspendLayout();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel4.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // button8
            // 
            button8.BackColor = Color.SteelBlue;
            button8.Dock = DockStyle.Top;
            button8.FlatAppearance.BorderColor = Color.SteelBlue;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.MouseDownBackColor = Color.Gray;
            button8.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Image = (Image)resources.GetObject("button8.Image");
            button8.ImageAlign = ContentAlignment.MiddleLeft;
            button8.Location = new Point(0, 468);
            button8.Margin = new Padding(4);
            button8.Name = "button8";
            button8.Size = new Size(250, 66);
            button8.TabIndex = 6;
            button8.Text = "Sair";
            button8.UseVisualStyleBackColor = false;
            // 
            // button5
            // 
            button5.BackColor = Color.SteelBlue;
            button5.Dock = DockStyle.Top;
            button5.FlatAppearance.BorderColor = Color.SteelBlue;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseDownBackColor = Color.Gray;
            button5.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(0, 402);
            button5.Margin = new Padding(4);
            button5.Name = "button5";
            button5.Size = new Size(250, 66);
            button5.TabIndex = 5;
            button5.Text = "Chamados";
            button5.UseVisualStyleBackColor = false;
            // 
            // button4
            // 
            button4.BackColor = Color.SteelBlue;
            button4.Dock = DockStyle.Top;
            button4.FlatAppearance.BorderColor = Color.SteelBlue;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseDownBackColor = Color.Gray;
            button4.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(0, 336);
            button4.Margin = new Padding(4);
            button4.Name = "button4";
            button4.Size = new Size(250, 66);
            button4.TabIndex = 4;
            button4.Text = "Férias";
            button4.UseVisualStyleBackColor = false;
            // 
            // button1
            // 
            button1.BackColor = Color.SteelBlue;
            button1.Dock = DockStyle.Top;
            button1.FlatAppearance.BorderColor = Color.SteelBlue;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.Gray;
            button1.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(0, 138);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(250, 66);
            button1.TabIndex = 1;
            button1.Text = "Home";
            button1.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightSteelBlue;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4);
            panel2.Name = "panel2";
            panel2.Size = new Size(250, 138);
            panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(58, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(131, 134);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // panel1
            // 
            panel1.BackColor = Color.SteelBlue;
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 553);
            panel1.TabIndex = 4;
            // 
            // button3
            // 
            button3.BackColor = Color.SteelBlue;
            button3.Dock = DockStyle.Top;
            button3.FlatAppearance.BorderColor = Color.SteelBlue;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.Gray;
            button3.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(0, 270);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.Size = new Size(250, 66);
            button3.TabIndex = 3;
            button3.Text = "Pagamento";
            button3.UseVisualStyleBackColor = false;
            // 
            // button2
            // 
            button2.BackColor = Color.SteelBlue;
            button2.Dock = DockStyle.Top;
            button2.FlatAppearance.BorderColor = Color.SteelBlue;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseDownBackColor = Color.Gray;
            button2.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(0, 204);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(250, 66);
            button2.TabIndex = 2;
            button2.Text = "Ponto";
            button2.UseVisualStyleBackColor = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(20, 34);
            label2.Name = "label2";
            label2.Size = new Size(147, 28);
            label2.TabIndex = 1;
            label2.Text = "Fábio Assis.";
            // 
            // panel5
            // 
            panel5.BackColor = Color.SteelBlue;
            panel5.Controls.Add(pictureBox5);
            panel5.Controls.Add(label5);
            panel5.Controls.Add(pictureBox2);
            panel5.Controls.Add(label2);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(250, 47);
            panel5.Name = "panel5";
            panel5.Size = new Size(732, 91);
            panel5.TabIndex = 7;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(650, 16);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(125, 76);
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(526, 35);
            label5.Name = "label5";
            label5.Size = new Size(118, 27);
            label5.TabIndex = 5;
            label5.Text = "Chamados";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(892, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(85, 62);
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(208, 9);
            label1.Name = "label1";
            label1.Size = new Size(326, 28);
            label1.TabIndex = 0;
            label1.Text = "LRSV - Software Factory";
            // 
            // panel4
            // 
            panel4.BackColor = Color.LightSteelBlue;
            panel4.Controls.Add(label1);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(250, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(732, 47);
            panel4.TabIndex = 6;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(430, 159);
            label3.Name = "label3";
            label3.Size = new Size(369, 25);
            label3.TabIndex = 9;
            label3.Text = "Efetuar uma abertuda de chamado.";
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(comboBox2);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label4);
            groupBox1.Location = new Point(294, 195);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(664, 293);
            groupBox1.TabIndex = 10;
            groupBox1.TabStop = false;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Baixa", "Média", "Alta", "Crítica" });
            comboBox2.Location = new Point(129, 84);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(173, 28);
            comboBox2.TabIndex = 24;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Ponto", "Sistema", "Folha de pagamento", "Benefícios" });
            comboBox1.Location = new Point(437, 84);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(198, 28);
            comboBox1.TabIndex = 23;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(129, 202);
            textBox3.Multiline = true;
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(512, 76);
            textBox3.TabIndex = 22;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(129, 136);
            textBox2.Multiline = true;
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(512, 44);
            textBox2.TabIndex = 21;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(129, 36);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(512, 28);
            textBox1.TabIndex = 20;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(24, 195);
            label9.Name = "label9";
            label9.Size = new Size(99, 20);
            label9.TabIndex = 19;
            label9.Text = "Descrição:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(24, 139);
            label8.Name = "label8";
            label8.Size = new Size(86, 20);
            label8.TabIndex = 18;
            label8.Text = "Resumo:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(24, 87);
            label7.Name = "label7";
            label7.Size = new Size(103, 20);
            label7.TabIndex = 17;
            label7.Text = "Prioridade:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(332, 87);
            label6.Name = "label6";
            label6.Size = new Size(99, 20);
            label6.TabIndex = 16;
            label6.Text = "Categoria:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(24, 39);
            label4.Name = "label4";
            label4.Size = new Size(65, 20);
            label4.TabIndex = 15;
            label4.Text = "Título:";
            // 
            // button6
            // 
            button6.BackColor = Color.LightSteelBlue;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(863, 503);
            button6.Name = "button6";
            button6.Size = new Size(95, 29);
            button6.TabIndex = 11;
            button6.Text = "Enviar";
            button6.UseVisualStyleBackColor = false;
            button6.Click += button6_Click;
            // 
            // button7
            // 
            button7.BackColor = Color.LightSteelBlue;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(294, 503);
            button7.Name = "button7";
            button7.Size = new Size(95, 29);
            button7.TabIndex = 12;
            button7.Text = "Cancelar";
            button7.UseVisualStyleBackColor = false;
            button7.Click += button7_Click;
            // 
            // linkLabel1
            // 
            linkLabel1.AutoSize = true;
            linkLabel1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            linkLabel1.Location = new Point(538, 512);
            linkLabel1.Name = "linkLabel1";
            linkLabel1.Size = new Size(145, 20);
            linkLabel1.TabIndex = 71;
            linkLabel1.TabStop = true;
            linkLabel1.Text = "Anexar arquivo.";
            // 
            // ChamadosFunc
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 553);
            Controls.Add(linkLabel1);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(groupBox1);
            Controls.Add(label3);
            Controls.Add(panel5);
            Controls.Add(panel4);
            Controls.Add(panel1);
            Name = "ChamadosFunc";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Chamados";
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            panel1.ResumeLayout(false);
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private Button button8;
        private Button button5;
        private Button button4;
        private Button button1;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Panel panel1;
        private Button button3;
        private Button button2;
        private Label label2;
        private Panel panel5;
        private PictureBox pictureBox5;
        private Label label5;
        private PictureBox pictureBox2;
        private Label label1;
        private Panel panel4;
        private Label label3;
        private GroupBox groupBox1;
        private Label label9;
        private Label label8;
        private Label label7;
        private Label label6;
        private Label label4;
        private ComboBox comboBox1;
        private TextBox textBox3;
        private TextBox textBox2;
        private TextBox textBox1;
        private ComboBox comboBox2;
        private Button button6;
        private Button button7;
        private LinkLabel linkLabel1;
    }
}