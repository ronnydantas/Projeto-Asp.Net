﻿namespace LRSV_pim
{
    partial class AltEspPonto
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            DataDeNascimento = new DateTimePicker();
            label4 = new Label();
            textBox3 = new TextBox();
            textBox4 = new TextBox();
            textBox5 = new TextBox();
            textBox6 = new TextBox();
            button2 = new Button();
            button3 = new Button();
            button4 = new Button();
            button5 = new Button();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            textBox10 = new TextBox();
            button6 = new Button();
            button7 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(40, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(729, 167);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Digite o CPF do colaborador que deseja realizar a alteração no espelho de ponto, logo após clique em \"Buscar\" para realizar a pesquisa no banco de dados.";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(88, 79);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(257, 27);
            textBox1.TabIndex = 5;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(607, 120);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(11, 78);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 3;
            label1.Text = "CPF:";
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Menu;
            textBox2.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(209, 198);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(180, 23);
            textBox2.TabIndex = 12;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(40, 201);
            label2.Name = "label2";
            label2.Size = new Size(152, 20);
            label2.TabIndex = 11;
            label2.Text = "Nome completo:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(40, 244);
            label3.Name = "label3";
            label3.Size = new Size(68, 20);
            label3.TabIndex = 13;
            label3.Text = "Filtrar:";
            // 
            // DataDeNascimento
            // 
            DataDeNascimento.CalendarFont = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            DataDeNascimento.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            DataDeNascimento.Location = new Point(209, 254);
            DataDeNascimento.MaxDate = new DateTime(2023, 12, 10, 0, 0, 0, 0);
            DataDeNascimento.MinDate = new DateTime(1900, 1, 1, 0, 0, 0, 0);
            DataDeNascimento.Name = "DataDeNascimento";
            DataDeNascimento.Size = new Size(314, 23);
            DataDeNascimento.TabIndex = 42;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(40, 297);
            label4.Name = "label4";
            label4.Size = new Size(163, 20);
            label4.TabIndex = 43;
            label4.Text = "Batidas de ponto:";
            // 
            // textBox3
            // 
            textBox3.BackColor = SystemColors.Menu;
            textBox3.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(209, 294);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(125, 27);
            textBox3.TabIndex = 44;
            // 
            // textBox4
            // 
            textBox4.BackColor = SystemColors.Menu;
            textBox4.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(209, 328);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(125, 27);
            textBox4.TabIndex = 45;
            // 
            // textBox5
            // 
            textBox5.BackColor = SystemColors.Menu;
            textBox5.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(209, 362);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(125, 27);
            textBox5.TabIndex = 46;
            // 
            // textBox6
            // 
            textBox6.BackColor = SystemColors.Menu;
            textBox6.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(209, 396);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(125, 27);
            textBox6.TabIndex = 47;
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(365, 293);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 48;
            button2.Text = "Alterar";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(365, 328);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 49;
            button3.Text = "Alterar";
            button3.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(365, 361);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 50;
            button4.Text = "Alterar";
            button4.UseVisualStyleBackColor = true;
            // 
            // button5
            // 
            button5.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(365, 395);
            button5.Name = "button5";
            button5.Size = new Size(94, 29);
            button5.TabIndex = 51;
            button5.Text = "Alterar";
            button5.UseVisualStyleBackColor = true;
            // 
            // textBox7
            // 
            textBox7.BackColor = SystemColors.Window;
            textBox7.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox7.Location = new Point(498, 399);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(125, 27);
            textBox7.TabIndex = 55;
            // 
            // textBox8
            // 
            textBox8.BackColor = SystemColors.Window;
            textBox8.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox8.Location = new Point(498, 365);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(125, 27);
            textBox8.TabIndex = 54;
            // 
            // textBox9
            // 
            textBox9.BackColor = SystemColors.Window;
            textBox9.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox9.Location = new Point(498, 331);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(125, 27);
            textBox9.TabIndex = 53;
            // 
            // textBox10
            // 
            textBox10.BackColor = SystemColors.Window;
            textBox10.Font = new Font("Microsoft Sans Serif", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox10.Location = new Point(498, 297);
            textBox10.Name = "textBox10";
            textBox10.Size = new Size(125, 27);
            textBox10.TabIndex = 52;
            // 
            // button6
            // 
            button6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(656, 399);
            button6.Name = "button6";
            button6.Size = new Size(113, 29);
            button6.TabIndex = 60;
            button6.Text = "Confirmar";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(40, 399);
            button7.Name = "button7";
            button7.Size = new Size(94, 29);
            button7.TabIndex = 61;
            button7.Text = "Voltar";
            button7.UseVisualStyleBackColor = true;
            // 
            // AltEspPonto
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button7);
            Controls.Add(button6);
            Controls.Add(textBox7);
            Controls.Add(textBox8);
            Controls.Add(textBox9);
            Controls.Add(textBox10);
            Controls.Add(button5);
            Controls.Add(button4);
            Controls.Add(button3);
            Controls.Add(button2);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(textBox3);
            Controls.Add(label4);
            Controls.Add(DataDeNascimento);
            Controls.Add(label3);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(groupBox1);
            Name = "AltEspPonto";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Alteração de espelho de ponto";
            Load += AltEspPonto_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox1;
        private Button button1;
        private Label label1;
        private TextBox textBox2;
        private Label label2;
        private Label label3;
        private DateTimePicker DataDeNascimento;
        private Label label4;
        private TextBox textBox3;
        private TextBox textBox4;
        private TextBox textBox5;
        private TextBox textBox6;
        private Button button2;
        private Button button3;
        private Button button4;
        private Button button5;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private TextBox textBox10;
        private Button button6;
        private Button button7;
    }
}