using System;
using System.Threading;

namespace LRSV_pim
{
    public partial class Login : Form
    {
        Thread nt;
        public Login()
        {
            InitializeComponent();
        }

        private void label3_Click(object sender, EventArgs e)
        {

        }

        private void button1_Click(object sender, EventArgs e)
        {
            if (textBox1.Text == "pim" && textBox2.Text == "pim")
            {
                this.Close();
                nt = new Thread(formAdm);
                nt.SetApartmentState(ApartmentState.STA);
                nt.Start();
            }
            if (textBox1.Text == "pim2" && textBox2.Text == "pim2")
            {
                this.Close();
                nt = new Thread(formColaborador);
                nt.SetApartmentState(ApartmentState.STA);
                nt.Start();
            }
            else
            {
                MessageBox.Show("Login ou senha inv�lidos!");
            }
        }

        private void formColaborador(object? obj)
        {
            Application.Run(new Colaborador());
        }

        private void formAdm(object? obj)
        {
            Application.Run(new Administrador());
        }

        private void Form1_Load(object sender, EventArgs e)
        {

        }

        private void button2_Click(object sender, EventArgs e)
        {
            MessageBox.Show("Foi enviado um e-mail (admlrsv@lrsv.com.br) com uma senha provis�ria aleat�ria, acesse e confira a senha fornecida para se logar.");
        }
    }
}