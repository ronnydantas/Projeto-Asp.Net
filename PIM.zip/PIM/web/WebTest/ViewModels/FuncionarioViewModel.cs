﻿namespace WebTest.ViewModels
{
    public class FuncionarioViewModel
    {
        public string Nome { get; set; }
        public string Cargo { get; set; }
        public int Salario { get; set; }
    }

}
