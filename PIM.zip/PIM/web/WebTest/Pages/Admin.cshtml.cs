using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebTest.Pages
{
    public class AdminModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
