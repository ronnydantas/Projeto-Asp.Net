using Microsoft.AspNetCore.Mvc;
using Microsoft.AspNetCore.Mvc.RazorPages;

namespace WebTest.Pages
{
    public class TransmitirArquivosModel : PageModel
    {
        public void OnGet()
        {
        }
    }
}
