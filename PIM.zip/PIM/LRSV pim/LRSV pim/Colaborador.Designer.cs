﻿namespace LRSV_pim
{
    partial class Colaborador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            System.ComponentModel.ComponentResourceManager resources = new System.ComponentModel.ComponentResourceManager(typeof(Colaborador));
            panel3 = new Panel();
            panel7 = new Panel();
            button7 = new Button();
            pictureBox4 = new PictureBox();
            label4 = new Label();
            panel6 = new Panel();
            button6 = new Button();
            pictureBox3 = new PictureBox();
            label3 = new Label();
            panel5 = new Panel();
            pictureBox5 = new PictureBox();
            label5 = new Label();
            pictureBox2 = new PictureBox();
            label2 = new Label();
            panel4 = new Panel();
            label1 = new Label();
            panel1 = new Panel();
            button8 = new Button();
            button5 = new Button();
            button4 = new Button();
            button3 = new Button();
            button2 = new Button();
            button1 = new Button();
            panel2 = new Panel();
            pictureBox1 = new PictureBox();
            panel3.SuspendLayout();
            panel7.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).BeginInit();
            panel6.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).BeginInit();
            panel5.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).BeginInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).BeginInit();
            panel4.SuspendLayout();
            panel1.SuspendLayout();
            panel2.SuspendLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox1).BeginInit();
            SuspendLayout();
            // 
            // panel3
            // 
            panel3.Controls.Add(panel7);
            panel3.Controls.Add(panel6);
            panel3.Controls.Add(panel5);
            panel3.Controls.Add(panel4);
            panel3.Dock = DockStyle.Fill;
            panel3.Location = new Point(250, 0);
            panel3.Margin = new Padding(4);
            panel3.Name = "panel3";
            panel3.Size = new Size(732, 553);
            panel3.TabIndex = 3;
            // 
            // panel7
            // 
            panel7.BorderStyle = BorderStyle.FixedSingle;
            panel7.Controls.Add(button7);
            panel7.Controls.Add(pictureBox4);
            panel7.Controls.Add(label4);
            panel7.Location = new Point(397, 184);
            panel7.Name = "panel7";
            panel7.Size = new Size(246, 318);
            panel7.TabIndex = 3;
            // 
            // button7
            // 
            button7.BackColor = Color.LightSteelBlue;
            button7.FlatStyle = FlatStyle.Flat;
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(20, 254);
            button7.Name = "button7";
            button7.Size = new Size(206, 29);
            button7.TabIndex = 2;
            button7.Text = "Baixar holerite atual";
            button7.UseVisualStyleBackColor = false;
            // 
            // pictureBox4
            // 
            pictureBox4.Image = (Image)resources.GetObject("pictureBox4.Image");
            pictureBox4.Location = new Point(58, 85);
            pictureBox4.Name = "pictureBox4";
            pictureBox4.Size = new Size(131, 132);
            pictureBox4.TabIndex = 1;
            pictureBox4.TabStop = false;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.BorderStyle = BorderStyle.Fixed3D;
            label4.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label4.Location = new Point(61, 19);
            label4.Name = "label4";
            label4.Size = new Size(128, 22);
            label4.TabIndex = 0;
            label4.Text = "Pagamentos";
            // 
            // panel6
            // 
            panel6.BorderStyle = BorderStyle.FixedSingle;
            panel6.Controls.Add(button6);
            panel6.Controls.Add(pictureBox3);
            panel6.Controls.Add(label3);
            panel6.Location = new Point(72, 184);
            panel6.Name = "panel6";
            panel6.Size = new Size(246, 318);
            panel6.TabIndex = 2;
            // 
            // button6
            // 
            button6.BackColor = Color.LightSteelBlue;
            button6.FlatStyle = FlatStyle.Flat;
            button6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(39, 254);
            button6.Name = "button6";
            button6.Size = new Size(163, 29);
            button6.TabIndex = 2;
            button6.Text = "Bater ponto";
            button6.UseVisualStyleBackColor = false;
            // 
            // pictureBox3
            // 
            pictureBox3.Image = (Image)resources.GetObject("pictureBox3.Image");
            pictureBox3.Location = new Point(58, 85);
            pictureBox3.Name = "pictureBox3";
            pictureBox3.Size = new Size(131, 132);
            pictureBox3.TabIndex = 1;
            pictureBox3.TabStop = false;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.BorderStyle = BorderStyle.Fixed3D;
            label3.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            label3.Location = new Point(39, 19);
            label3.Name = "label3";
            label3.Size = new Size(163, 22);
            label3.TabIndex = 0;
            label3.Text = "Batida de ponto";
            // 
            // panel5
            // 
            panel5.BackColor = Color.SteelBlue;
            panel5.Controls.Add(pictureBox5);
            panel5.Controls.Add(label5);
            panel5.Controls.Add(pictureBox2);
            panel5.Controls.Add(label2);
            panel5.Dock = DockStyle.Top;
            panel5.Location = new Point(0, 47);
            panel5.Name = "panel5";
            panel5.Size = new Size(732, 91);
            panel5.TabIndex = 1;
            // 
            // pictureBox5
            // 
            pictureBox5.Image = (Image)resources.GetObject("pictureBox5.Image");
            pictureBox5.Location = new Point(650, 16);
            pictureBox5.Name = "pictureBox5";
            pictureBox5.Size = new Size(125, 75);
            pictureBox5.TabIndex = 6;
            pictureBox5.TabStop = false;
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.BorderStyle = BorderStyle.FixedSingle;
            label5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(574, 37);
            label5.Name = "label5";
            label5.Size = new Size(72, 27);
            label5.TabIndex = 5;
            label5.Text = "Home";
            // 
            // pictureBox2
            // 
            pictureBox2.Image = (Image)resources.GetObject("pictureBox2.Image");
            pictureBox2.Location = new Point(892, 16);
            pictureBox2.Name = "pictureBox2";
            pictureBox2.Size = new Size(85, 62);
            pictureBox2.TabIndex = 2;
            pictureBox2.TabStop = false;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 13.8F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(20, 34);
            label2.Name = "label2";
            label2.Size = new Size(298, 28);
            label2.TabIndex = 1;
            label2.Text = "Bem-vindo, colaborador!";
            // 
            // panel4
            // 
            panel4.BackColor = Color.LightSteelBlue;
            panel4.Controls.Add(label1);
            panel4.Dock = DockStyle.Top;
            panel4.Location = new Point(0, 0);
            panel4.Name = "panel4";
            panel4.Size = new Size(732, 47);
            panel4.TabIndex = 0;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(208, 9);
            label1.Name = "label1";
            label1.Size = new Size(326, 28);
            label1.TabIndex = 0;
            label1.Text = "LRSV - Software Factory";
            label1.Click += label1_Click_2;
            // 
            // panel1
            // 
            panel1.BackColor = Color.SteelBlue;
            panel1.Controls.Add(button8);
            panel1.Controls.Add(button5);
            panel1.Controls.Add(button4);
            panel1.Controls.Add(button3);
            panel1.Controls.Add(button2);
            panel1.Controls.Add(button1);
            panel1.Controls.Add(panel2);
            panel1.Dock = DockStyle.Left;
            panel1.Location = new Point(0, 0);
            panel1.Margin = new Padding(4);
            panel1.Name = "panel1";
            panel1.Size = new Size(250, 553);
            panel1.TabIndex = 2;
            // 
            // button8
            // 
            button8.BackColor = Color.SteelBlue;
            button8.Dock = DockStyle.Top;
            button8.FlatAppearance.BorderColor = Color.SteelBlue;
            button8.FlatAppearance.BorderSize = 0;
            button8.FlatAppearance.MouseDownBackColor = Color.Gray;
            button8.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button8.FlatStyle = FlatStyle.Flat;
            button8.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Image = (Image)resources.GetObject("button8.Image");
            button8.ImageAlign = ContentAlignment.MiddleLeft;
            button8.Location = new Point(0, 468);
            button8.Margin = new Padding(4);
            button8.Name = "button8";
            button8.Size = new Size(250, 66);
            button8.TabIndex = 6;
            button8.Text = "Sair";
            button8.UseVisualStyleBackColor = false;
            button8.Click += button8_Click;
            // 
            // button5
            // 
            button5.BackColor = Color.SteelBlue;
            button5.Dock = DockStyle.Top;
            button5.FlatAppearance.BorderColor = Color.SteelBlue;
            button5.FlatAppearance.BorderSize = 0;
            button5.FlatAppearance.MouseDownBackColor = Color.Gray;
            button5.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button5.FlatStyle = FlatStyle.Flat;
            button5.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Image = (Image)resources.GetObject("button5.Image");
            button5.ImageAlign = ContentAlignment.MiddleLeft;
            button5.Location = new Point(0, 402);
            button5.Margin = new Padding(4);
            button5.Name = "button5";
            button5.Size = new Size(250, 66);
            button5.TabIndex = 5;
            button5.Text = "Chamados";
            button5.UseVisualStyleBackColor = false;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.BackColor = Color.SteelBlue;
            button4.Dock = DockStyle.Top;
            button4.FlatAppearance.BorderColor = Color.SteelBlue;
            button4.FlatAppearance.BorderSize = 0;
            button4.FlatAppearance.MouseDownBackColor = Color.Gray;
            button4.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button4.FlatStyle = FlatStyle.Flat;
            button4.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Image = (Image)resources.GetObject("button4.Image");
            button4.ImageAlign = ContentAlignment.MiddleLeft;
            button4.Location = new Point(0, 336);
            button4.Margin = new Padding(4);
            button4.Name = "button4";
            button4.Size = new Size(250, 66);
            button4.TabIndex = 4;
            button4.Text = "Férias";
            button4.UseVisualStyleBackColor = false;
            button4.Click += button4_Click;
            // 
            // button3
            // 
            button3.BackColor = Color.SteelBlue;
            button3.Dock = DockStyle.Top;
            button3.FlatAppearance.BorderColor = Color.SteelBlue;
            button3.FlatAppearance.BorderSize = 0;
            button3.FlatAppearance.MouseDownBackColor = Color.Gray;
            button3.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button3.FlatStyle = FlatStyle.Flat;
            button3.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Image = (Image)resources.GetObject("button3.Image");
            button3.ImageAlign = ContentAlignment.MiddleLeft;
            button3.Location = new Point(0, 270);
            button3.Margin = new Padding(4);
            button3.Name = "button3";
            button3.Size = new Size(250, 66);
            button3.TabIndex = 3;
            button3.Text = "Pagamento";
            button3.UseVisualStyleBackColor = false;
            button3.Click += button3_Click_1;
            // 
            // button2
            // 
            button2.BackColor = Color.SteelBlue;
            button2.Dock = DockStyle.Top;
            button2.FlatAppearance.BorderColor = Color.SteelBlue;
            button2.FlatAppearance.BorderSize = 0;
            button2.FlatAppearance.MouseDownBackColor = Color.Gray;
            button2.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button2.FlatStyle = FlatStyle.Flat;
            button2.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Image = (Image)resources.GetObject("button2.Image");
            button2.ImageAlign = ContentAlignment.MiddleLeft;
            button2.Location = new Point(0, 204);
            button2.Margin = new Padding(4);
            button2.Name = "button2";
            button2.Size = new Size(250, 66);
            button2.TabIndex = 2;
            button2.Text = "Ponto";
            button2.UseVisualStyleBackColor = false;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.BackColor = Color.SteelBlue;
            button1.Dock = DockStyle.Top;
            button1.FlatAppearance.BorderColor = Color.SteelBlue;
            button1.FlatAppearance.BorderSize = 0;
            button1.FlatAppearance.MouseDownBackColor = Color.Gray;
            button1.FlatAppearance.MouseOverBackColor = Color.LavenderBlush;
            button1.FlatStyle = FlatStyle.Flat;
            button1.Font = new Font("Verdana", 12F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Image = (Image)resources.GetObject("button1.Image");
            button1.ImageAlign = ContentAlignment.MiddleLeft;
            button1.Location = new Point(0, 138);
            button1.Margin = new Padding(4);
            button1.Name = "button1";
            button1.Size = new Size(250, 66);
            button1.TabIndex = 1;
            button1.Text = "Home";
            button1.UseVisualStyleBackColor = false;
            // 
            // panel2
            // 
            panel2.BackColor = Color.LightSteelBlue;
            panel2.BorderStyle = BorderStyle.FixedSingle;
            panel2.Controls.Add(pictureBox1);
            panel2.Dock = DockStyle.Top;
            panel2.Location = new Point(0, 0);
            panel2.Margin = new Padding(4);
            panel2.Name = "panel2";
            panel2.Size = new Size(250, 138);
            panel2.TabIndex = 0;
            // 
            // pictureBox1
            // 
            pictureBox1.Image = (Image)resources.GetObject("pictureBox1.Image");
            pictureBox1.Location = new Point(58, 4);
            pictureBox1.Name = "pictureBox1";
            pictureBox1.Size = new Size(131, 134);
            pictureBox1.TabIndex = 0;
            pictureBox1.TabStop = false;
            // 
            // Colaborador
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(982, 553);
            Controls.Add(panel3);
            Controls.Add(panel1);
            Name = "Colaborador";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Colaborador";
            panel3.ResumeLayout(false);
            panel7.ResumeLayout(false);
            panel7.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox4).EndInit();
            panel6.ResumeLayout(false);
            panel6.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox3).EndInit();
            panel5.ResumeLayout(false);
            panel5.PerformLayout();
            ((System.ComponentModel.ISupportInitialize)pictureBox5).EndInit();
            ((System.ComponentModel.ISupportInitialize)pictureBox2).EndInit();
            panel4.ResumeLayout(false);
            panel4.PerformLayout();
            panel1.ResumeLayout(false);
            panel2.ResumeLayout(false);
            ((System.ComponentModel.ISupportInitialize)pictureBox1).EndInit();
            ResumeLayout(false);
        }

        #endregion

        private Panel panel3;
        private Panel panel1;
        private Button button5;
        private Button button4;
        private Button button3;
        private Button button2;
        private Button button1;
        private Panel panel2;
        private PictureBox pictureBox1;
        private Panel panel4;
        private Label label1;
        private Panel panel5;
        private Label label2;
        private PictureBox pictureBox2;
        private Panel panel6;
        private Button button6;
        private PictureBox pictureBox3;
        private Label label3;
        private Panel panel7;
        private Button button7;
        private PictureBox pictureBox4;
        private Label label4;
        private Label label5;
        private PictureBox pictureBox5;
        private Button button8;
    }
}