﻿namespace LRSV_pim
{
    partial class Colaborador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            menuStrip1 = new MenuStrip();
            homeToolStripMenuItem = new ToolStripMenuItem();
            pontoToolStripMenuItem = new ToolStripMenuItem();
            pagamentosToolStripMenuItem = new ToolStripMenuItem();
            fériasToolStripMenuItem = new ToolStripMenuItem();
            button3 = new Button();
            groupBox1 = new GroupBox();
            button2 = new Button();
            button1 = new Button();
            menuStrip1.SuspendLayout();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // menuStrip1
            // 
            menuStrip1.ImageScalingSize = new Size(20, 20);
            menuStrip1.Items.AddRange(new ToolStripItem[] { homeToolStripMenuItem, pontoToolStripMenuItem, pagamentosToolStripMenuItem, fériasToolStripMenuItem });
            menuStrip1.Location = new Point(0, 0);
            menuStrip1.Name = "menuStrip1";
            menuStrip1.Size = new Size(800, 26);
            menuStrip1.TabIndex = 0;
            menuStrip1.Text = "menuStrip1";
            // 
            // homeToolStripMenuItem
            // 
            homeToolStripMenuItem.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            homeToolStripMenuItem.Name = "homeToolStripMenuItem";
            homeToolStripMenuItem.Size = new Size(67, 22);
            homeToolStripMenuItem.Text = "Home";
            // 
            // pontoToolStripMenuItem
            // 
            pontoToolStripMenuItem.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            pontoToolStripMenuItem.Name = "pontoToolStripMenuItem";
            pontoToolStripMenuItem.Size = new Size(66, 22);
            pontoToolStripMenuItem.Text = "Ponto";
            // 
            // pagamentosToolStripMenuItem
            // 
            pagamentosToolStripMenuItem.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            pagamentosToolStripMenuItem.Name = "pagamentosToolStripMenuItem";
            pagamentosToolStripMenuItem.Size = new Size(115, 22);
            pagamentosToolStripMenuItem.Text = "Pagamentos";
            // 
            // fériasToolStripMenuItem
            // 
            fériasToolStripMenuItem.Font = new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point);
            fériasToolStripMenuItem.Name = "fériasToolStripMenuItem";
            fériasToolStripMenuItem.Size = new Size(66, 22);
            fériasToolStripMenuItem.Text = "Férias";
            // 
            // button3
            // 
            button3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(443, 224);
            button3.Name = "button3";
            button3.Size = new Size(128, 51);
            button3.TabIndex = 4;
            button3.Text = "Ver pagamento completo";
            button3.UseVisualStyleBackColor = true;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(53, 61);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(208, 236);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Ponto";
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(30, 143);
            button2.Name = "button2";
            button2.Size = new Size(149, 72);
            button2.TabIndex = 8;
            button2.Text = "Ver ponto completo";
            button2.UseVisualStyleBackColor = true;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(30, 47);
            button1.Name = "button1";
            button1.Size = new Size(149, 76);
            button1.TabIndex = 7;
            button1.Text = "Bater ponto";
            button1.UseVisualStyleBackColor = true;
            // 
            // Colaborador
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Controls.Add(button3);
            Controls.Add(menuStrip1);
            MainMenuStrip = menuStrip1;
            Name = "Colaborador";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Colaborador - LRSV Software Factory";
            menuStrip1.ResumeLayout(false);
            menuStrip1.PerformLayout();
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private MenuStrip menuStrip1;
        private ToolStripMenuItem homeToolStripMenuItem;
        private ToolStripMenuItem pontoToolStripMenuItem;
        private ToolStripMenuItem pagamentosToolStripMenuItem;
        private ToolStripMenuItem fériasToolStripMenuItem;
        private Button button3;
        private GroupBox groupBox1;
        private Button button2;
        private Button button1;
    }
}