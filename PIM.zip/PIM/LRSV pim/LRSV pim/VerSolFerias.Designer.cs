﻿namespace LRSV_pim
{
    partial class VerSolFerias
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListViewItem listViewItem1 = new ListViewItem(new ListViewItem.ListViewSubItem[] { new ListViewItem.ListViewSubItem(null, "Fábio Assis", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Gerente de TI", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "14/08/2023", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Sem registro de férias anteriores", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 9F, FontStyle.Regular, GraphicsUnit.Point)) }, -1);
            groupBox1 = new GroupBox();
            checkBox1 = new CheckBox();
            textBox1 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            groupBox2 = new GroupBox();
            button3 = new Button();
            button2 = new Button();
            dateTimePicker2 = new DateTimePicker();
            label4 = new Label();
            label3 = new Label();
            dateTimePicker1 = new DateTimePicker();
            button4 = new Button();
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(checkBox1);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(30, 25);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(729, 149);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Digite o CPF do colaborador que deseja consultar a solicitação de agendamento de férias, logo após clique em \"Filtrar\".";
            // 
            // checkBox1
            // 
            checkBox1.AutoSize = true;
            checkBox1.Location = new Point(133, 109);
            checkBox1.Name = "checkBox1";
            checkBox1.Size = new Size(301, 24);
            checkBox1.TabIndex = 6;
            checkBox1.Text = "Filtrar todos os funcionários";
            checkBox1.UseVisualStyleBackColor = true;
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Menu;
            textBox1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(77, 65);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(257, 28);
            textBox1.TabIndex = 5;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(602, 104);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Filtrar";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(0, 64);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 3;
            label1.Text = "CPF:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button3);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(dateTimePicker2);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(label3);
            groupBox2.Controls.Add(dateTimePicker1);
            groupBox2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            groupBox2.Location = new Point(30, 277);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(729, 126);
            groupBox2.TabIndex = 57;
            groupBox2.TabStop = false;
            groupBox2.Text = "Período solicitado";
            // 
            // button3
            // 
            button3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(591, 71);
            button3.Name = "button3";
            button3.Size = new Size(94, 29);
            button3.TabIndex = 65;
            button3.Text = "Agendar";
            button3.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(446, 71);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 64;
            button2.Text = "Alterar";
            button2.UseVisualStyleBackColor = true;
            // 
            // dateTimePicker2
            // 
            dateTimePicker2.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            dateTimePicker2.Location = new Point(120, 77);
            dateTimePicker2.Name = "dateTimePicker2";
            dateTimePicker2.Size = new Size(293, 23);
            dateTimePicker2.TabIndex = 63;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(6, 80);
            label4.Name = "label4";
            label4.Size = new Size(91, 20);
            label4.TabIndex = 62;
            label4.Text = "Data fim:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(6, 39);
            label3.Name = "label3";
            label3.Size = new Size(108, 20);
            label3.TabIndex = 58;
            label3.Text = "Data início:";
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            dateTimePicker1.Location = new Point(120, 39);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(293, 23);
            dateTimePicker1.TabIndex = 61;
            // 
            // button4
            // 
            button4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(30, 409);
            button4.Name = "button4";
            button4.Size = new Size(94, 29);
            button4.TabIndex = 58;
            button4.Text = "Voltar";
            button4.UseVisualStyleBackColor = true;
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4 });
            listView1.Items.AddRange(new ListViewItem[] { listViewItem1 });
            listView1.Location = new Point(30, 180);
            listView1.Name = "listView1";
            listView1.Size = new Size(729, 91);
            listView1.TabIndex = 59;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Nome";
            columnHeader1.Width = 200;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Cargo";
            columnHeader2.TextAlign = HorizontalAlignment.Center;
            columnHeader2.Width = 200;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Data de admissão";
            columnHeader3.TextAlign = HorizontalAlignment.Center;
            columnHeader3.Width = 200;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Últimas férias";
            columnHeader4.TextAlign = HorizontalAlignment.Center;
            columnHeader4.Width = 200;
            // 
            // VerSolFerias
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(listView1);
            Controls.Add(button4);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "VerSolFerias";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Solicitações de férias";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button button1;
        private Label label1;
        private CheckBox checkBox1;
        private TextBox textBox1;
        private GroupBox groupBox2;
        private DateTimePicker dateTimePicker2;
        private Label label4;
        private Label label3;
        private DateTimePicker dateTimePicker1;
        private Button button3;
        private Button button2;
        private Button button4;
        private ListView listView1;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
    }
}