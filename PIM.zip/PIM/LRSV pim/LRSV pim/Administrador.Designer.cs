﻿namespace LRSV_pim
{
    partial class Administrador
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            dateTimePicker1 = new DateTimePicker();
            button1 = new Button();
            button2 = new Button();
            button3 = new Button();
            button7 = new Button();
            button8 = new Button();
            button10 = new Button();
            groupBox1 = new GroupBox();
            button11 = new Button();
            button6 = new Button();
            button5 = new Button();
            button4 = new Button();
            button9 = new Button();
            label1 = new Label();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // dateTimePicker1
            // 
            dateTimePicker1.Location = new Point(445, 400);
            dateTimePicker1.Name = "dateTimePicker1";
            dateTimePicker1.Size = new Size(330, 27);
            dateTimePicker1.TabIndex = 3;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(32, 36);
            button1.Name = "button1";
            button1.Size = new Size(195, 51);
            button1.TabIndex = 15;
            button1.Text = "Admitir empregado";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(435, 117);
            button2.Name = "button2";
            button2.Size = new Size(189, 51);
            button2.TabIndex = 16;
            button2.Text = "Alterar dados de colaboradores";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button3
            // 
            button3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(435, 36);
            button3.Name = "button3";
            button3.Size = new Size(189, 51);
            button3.TabIndex = 17;
            button3.Text = "Transmitir arquivos";
            button3.UseVisualStyleBackColor = true;
            button3.Click += button3_Click;
            // 
            // button7
            // 
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(233, 117);
            button7.Name = "button7";
            button7.Size = new Size(191, 51);
            button7.TabIndex = 21;
            button7.Text = "Férias";
            button7.UseVisualStyleBackColor = true;
            button7.Click += button7_Click;
            // 
            // button8
            // 
            button8.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button8.Location = new Point(233, 36);
            button8.Name = "button8";
            button8.Size = new Size(191, 51);
            button8.TabIndex = 22;
            button8.Text = "Inclusão de benefícios";
            button8.UseVisualStyleBackColor = true;
            button8.Click += button8_Click;
            // 
            // button10
            // 
            button10.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button10.Location = new Point(32, 117);
            button10.Name = "button10";
            button10.Size = new Size(195, 51);
            button10.TabIndex = 24;
            button10.Text = "Pagamentos adicionais";
            button10.UseVisualStyleBackColor = true;
            button10.Click += button10_Click;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button11);
            groupBox1.Controls.Add(button6);
            groupBox1.Controls.Add(button5);
            groupBox1.Controls.Add(button4);
            groupBox1.Controls.Add(button10);
            groupBox1.Controls.Add(button8);
            groupBox1.Controls.Add(button7);
            groupBox1.Controls.Add(button3);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(62, 52);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(673, 331);
            groupBox1.TabIndex = 15;
            groupBox1.TabStop = false;
            groupBox1.Text = "Painel do ADM";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // button11
            // 
            button11.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button11.Location = new Point(239, 265);
            button11.Name = "button11";
            button11.Size = new Size(189, 51);
            button11.TabIndex = 28;
            button11.Text = "Chamados";
            button11.UseVisualStyleBackColor = true;
            button11.Click += button11_Click_1;
            // 
            // button6
            // 
            button6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(435, 199);
            button6.Name = "button6";
            button6.Size = new Size(189, 51);
            button6.TabIndex = 27;
            button6.Text = "Relatórios";
            button6.UseVisualStyleBackColor = true;
            button6.Click += button6_Click_1;
            // 
            // button5
            // 
            button5.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(233, 199);
            button5.Name = "button5";
            button5.Size = new Size(195, 51);
            button5.TabIndex = 26;
            button5.Text = "Holerites";
            button5.UseVisualStyleBackColor = true;
            button5.Click += button5_Click;
            // 
            // button4
            // 
            button4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(32, 199);
            button4.Name = "button4";
            button4.Size = new Size(195, 51);
            button4.TabIndex = 25;
            button4.Text = "Alteração no espelho de ponto";
            button4.UseVisualStyleBackColor = true;
            button4.Click += button4_Click;
            // 
            // button9
            // 
            button9.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button9.Location = new Point(23, 400);
            button9.Name = "button9";
            button9.Size = new Size(248, 29);
            button9.TabIndex = 67;
            button9.Text = "Logar como colaborador";
            button9.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.BorderStyle = BorderStyle.FixedSingle;
            label1.Font = new Font("Verdana", 13.8F, FontStyle.Bold, GraphicsUnit.Point);
            label1.Location = new Point(209, 9);
            label1.Name = "label1";
            label1.Size = new Size(382, 30);
            label1.TabIndex = 68;
            label1.Text = "LRSV - SOFTWARE FACTORY";
            // 
            // Administrador
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(label1);
            Controls.Add(button9);
            Controls.Add(groupBox1);
            Controls.Add(dateTimePicker1);
            Name = "Administrador";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Administrador - LRSV Software Factory";
            Load += Administrador_Load;
            groupBox1.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion
        private DateTimePicker dateTimePicker1;
        private Button button1;
        private Button button2;
        private Button button3;
        private Button button7;
        private Button button8;
        private Button button10;
        private GroupBox groupBox1;
        private Button button4;
        private Button button6;
        private Button button5;
        private Button button9;
        private Button button11;
        private Label label1;
    }
}