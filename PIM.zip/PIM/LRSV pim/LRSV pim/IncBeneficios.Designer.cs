﻿namespace LRSV_pim
{
    partial class IncBeneficios
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            groupBox2 = new GroupBox();
            button5 = new Button();
            button4 = new Button();
            button2 = new Button();
            button3 = new Button();
            button6 = new Button();
            button7 = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(26, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(729, 167);
            groupBox1.TabIndex = 4;
            groupBox1.TabStop = false;
            groupBox1.Text = "Digite o CPF do colaborador que deseja realizar a inclusão de benefícios, logo após clique em \"Buscar\" para realizar a pesquisa no banco de dados.";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(88, 79);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(257, 23);
            textBox1.TabIndex = 5;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(607, 120);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(11, 78);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 3;
            label1.Text = "CPF:";
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Menu;
            textBox2.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(195, 194);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(180, 23);
            textBox2.TabIndex = 14;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(26, 197);
            label2.Name = "label2";
            label2.Size = new Size(152, 20);
            label2.TabIndex = 13;
            label2.Text = "Nome completo:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button5);
            groupBox2.Controls.Add(button4);
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(button3);
            groupBox2.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(26, 260);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(729, 101);
            groupBox2.TabIndex = 64;
            groupBox2.TabStop = false;
            groupBox2.Text = "Incluir";
            // 
            // button5
            // 
            button5.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button5.Location = new Point(537, 40);
            button5.Name = "button5";
            button5.Size = new Size(152, 29);
            button5.TabIndex = 67;
            button5.Text = "Plano de saúde";
            button5.UseVisualStyleBackColor = true;
            // 
            // button4
            // 
            button4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button4.Location = new Point(355, 40);
            button4.Name = "button4";
            button4.Size = new Size(176, 29);
            button4.TabIndex = 66;
            button4.Text = "Vale-Alimentação";
            button4.UseVisualStyleBackColor = true;
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(197, 40);
            button2.Name = "button2";
            button2.Size = new Size(152, 29);
            button2.TabIndex = 65;
            button2.Text = "Vale-Refeição";
            button2.UseVisualStyleBackColor = true;
            // 
            // button3
            // 
            button3.BackColor = Color.Lime;
            button3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(39, 40);
            button3.Name = "button3";
            button3.Size = new Size(152, 29);
            button3.TabIndex = 64;
            button3.Text = "Vale-Transporte";
            button3.UseVisualStyleBackColor = false;
            // 
            // button6
            // 
            button6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button6.Location = new Point(642, 397);
            button6.Name = "button6";
            button6.Size = new Size(113, 29);
            button6.TabIndex = 66;
            button6.Text = "Confirmar";
            button6.UseVisualStyleBackColor = true;
            // 
            // button7
            // 
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(26, 397);
            button7.Name = "button7";
            button7.Size = new Size(94, 29);
            button7.TabIndex = 65;
            button7.Text = "Voltar";
            button7.UseVisualStyleBackColor = true;
            // 
            // IncBeneficios
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button6);
            Controls.Add(button7);
            Controls.Add(groupBox2);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(groupBox1);
            Name = "IncBeneficios";
            Text = "Inclusão beneficios";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox1;
        private Button button1;
        private Label label1;
        private TextBox textBox2;
        private Label label2;
        private GroupBox groupBox2;
        private Button button5;
        private Button button4;
        private Button button2;
        private Button button3;
        private Button button6;
        private Button button7;
    }
}