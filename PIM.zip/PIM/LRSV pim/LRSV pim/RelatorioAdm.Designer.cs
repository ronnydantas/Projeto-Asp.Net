﻿namespace LRSV_pim
{
    partial class RelatorioAdm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            label5 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            comboBox1 = new ComboBox();
            button7 = new Button();
            groupBox2 = new GroupBox();
            textBox4 = new TextBox();
            label4 = new Label();
            textBox3 = new TextBox();
            label3 = new Label();
            textBox1 = new TextBox();
            label1 = new Label();
            groupBox3 = new GroupBox();
            textBox8 = new TextBox();
            label8 = new Label();
            textBox7 = new TextBox();
            label7 = new Label();
            textBox6 = new TextBox();
            label6 = new Label();
            button1 = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            groupBox3.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(button7);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label2);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(12, 4);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(776, 118);
            groupBox1.TabIndex = 33;
            groupBox1.TabStop = false;
            groupBox1.Text = "Quantidade de colaboradores";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(6, 37);
            label5.Name = "label5";
            label5.Size = new Size(242, 20);
            label5.TabIndex = 29;
            label5.Text = "Selecione o departamento:";
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Menu;
            textBox2.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(651, 38);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(118, 23);
            textBox2.TabIndex = 28;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(401, 38);
            label2.Name = "label2";
            label2.Size = new Size(222, 20);
            label2.TabIndex = 27;
            label2.Text = "Número de funcionários:";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "RH", "DP", "TI", "ADM", "OP" });
            comboBox1.Location = new Point(244, 35);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(151, 28);
            comboBox1.TabIndex = 30;
            // 
            // button7
            // 
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(271, 77);
            button7.Name = "button7";
            button7.Size = new Size(94, 29);
            button7.TabIndex = 67;
            button7.Text = "Procurar";
            button7.UseVisualStyleBackColor = true;
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(textBox4);
            groupBox2.Controls.Add(label1);
            groupBox2.Controls.Add(label4);
            groupBox2.Controls.Add(textBox1);
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(label3);
            groupBox2.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(12, 128);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(776, 118);
            groupBox2.TabIndex = 68;
            groupBox2.TabStop = false;
            groupBox2.Text = "Despesas (salário, impostos e entre outros)...";
            // 
            // textBox4
            // 
            textBox4.BackColor = SystemColors.Menu;
            textBox4.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(376, 78);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(118, 23);
            textBox4.TabIndex = 74;
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(214, 77);
            label4.Name = "label4";
            label4.Size = new Size(119, 20);
            label4.TabIndex = 73;
            label4.Text = "Gasto anual:";
            // 
            // textBox3
            // 
            textBox3.BackColor = SystemColors.Menu;
            textBox3.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(563, 35);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(118, 23);
            textBox3.TabIndex = 72;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(401, 34);
            label3.Name = "label3";
            label3.Size = new Size(156, 20);
            label3.TabIndex = 71;
            label3.Text = "Gasto semestral:";
            // 
            // textBox1
            // 
            textBox1.BackColor = SystemColors.Menu;
            textBox1.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(165, 31);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(118, 23);
            textBox1.TabIndex = 70;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(6, 38);
            label1.Name = "label1";
            label1.Size = new Size(134, 20);
            label1.TabIndex = 69;
            label1.Text = "Gasto mensal:";
            // 
            // groupBox3
            // 
            groupBox3.Controls.Add(textBox8);
            groupBox3.Controls.Add(label6);
            groupBox3.Controls.Add(label8);
            groupBox3.Controls.Add(textBox6);
            groupBox3.Controls.Add(textBox7);
            groupBox3.Controls.Add(label7);
            groupBox3.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox3.Location = new Point(12, 261);
            groupBox3.Name = "groupBox3";
            groupBox3.Size = new Size(776, 135);
            groupBox3.TabIndex = 75;
            groupBox3.TabStop = false;
            groupBox3.Text = "Lucros";
            // 
            // textBox8
            // 
            textBox8.BackColor = SystemColors.Menu;
            textBox8.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox8.Location = new Point(385, 101);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(118, 23);
            textBox8.TabIndex = 81;
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(223, 100);
            label8.Name = "label8";
            label8.Size = new Size(116, 20);
            label8.TabIndex = 80;
            label8.Text = "Lucro anual:";
            // 
            // textBox7
            // 
            textBox7.BackColor = SystemColors.Menu;
            textBox7.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox7.Location = new Point(572, 48);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(118, 23);
            textBox7.TabIndex = 79;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(410, 47);
            label7.Name = "label7";
            label7.Size = new Size(153, 20);
            label7.TabIndex = 78;
            label7.Text = "Lucro semestral:";
            // 
            // textBox6
            // 
            textBox6.BackColor = SystemColors.Menu;
            textBox6.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(168, 44);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(118, 23);
            textBox6.TabIndex = 77;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(6, 43);
            label6.Name = "label6";
            label6.Size = new Size(131, 20);
            label6.TabIndex = 76;
            label6.Text = "Lucro mensal:";
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(18, 409);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 76;
            button1.Text = "Voltar";
            button1.UseVisualStyleBackColor = true;
            // 
            // RelatorioAdm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button1);
            Controls.Add(groupBox3);
            Controls.Add(groupBox2);
            Controls.Add(groupBox1);
            Name = "RelatorioAdm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Relatórios";
            Load += RelatorioAdm_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            groupBox3.ResumeLayout(false);
            groupBox3.PerformLayout();
            ResumeLayout(false);
        }

        #endregion
        private GroupBox groupBox1;
        private ComboBox comboBox1;
        private Label label5;
        private TextBox textBox2;
        private Label label2;
        private Button button7;
        private GroupBox groupBox2;
        private TextBox textBox4;
        private Label label1;
        private Label label4;
        private TextBox textBox1;
        private TextBox textBox3;
        private Label label3;
        private GroupBox groupBox3;
        private TextBox textBox8;
        private Label label6;
        private Label label8;
        private TextBox textBox6;
        private TextBox textBox7;
        private Label label7;
        private Button button1;
    }
}