﻿namespace LRSV_pim
{
    partial class AddEmpregado
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            label1 = new Label();
            textBox1 = new TextBox();
            label2 = new Label();
            label3 = new Label();
            label4 = new Label();
            label5 = new Label();
            label6 = new Label();
            label7 = new Label();
            label8 = new Label();
            label9 = new Label();
            textBox7 = new TextBox();
            textBox8 = new TextBox();
            textBox9 = new TextBox();
            groupBox1 = new GroupBox();
            DataDeNascimento = new DateTimePicker();
            comboBox1 = new ComboBox();
            label16 = new Label();
            textBox15 = new TextBox();
            label15 = new Label();
            textBox14 = new TextBox();
            label14 = new Label();
            textBox13 = new TextBox();
            label13 = new Label();
            textBox12 = new TextBox();
            label12 = new Label();
            textBox11 = new TextBox();
            label11 = new Label();
            label10 = new Label();
            button2 = new Button();
            button1 = new Button();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            textBox3 = new TextBox();
            textBox2 = new TextBox();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(30, 37);
            label1.Name = "label1";
            label1.Size = new Size(152, 20);
            label1.TabIndex = 7;
            label1.Text = "Nome completo:";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(221, 34);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(180, 23);
            textBox1.TabIndex = 8;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(30, 77);
            label2.Name = "label2";
            label2.Size = new Size(49, 20);
            label2.TabIndex = 9;
            label2.Text = "CPF:";
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(30, 119);
            label3.Name = "label3";
            label3.Size = new Size(42, 20);
            label3.TabIndex = 10;
            label3.Text = "RG:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(30, 243);
            label4.Name = "label4";
            label4.Size = new Size(87, 20);
            label4.TabIndex = 11;
            label4.Text = "Telefone:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(30, 284);
            label5.Name = "label5";
            label5.Size = new Size(73, 20);
            label5.TabIndex = 12;
            label5.Text = "E-mail:";
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(30, 331);
            label6.Name = "label6";
            label6.Size = new Size(96, 20);
            label6.TabIndex = 13;
            label6.Text = "Endereço:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(407, 37);
            label7.Name = "label7";
            label7.Size = new Size(67, 20);
            label7.TabIndex = 19;
            label7.Text = "Cargo:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(407, 77);
            label8.Name = "label8";
            label8.Size = new Size(76, 20);
            label8.TabIndex = 20;
            label8.Text = "Salário:";
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(407, 120);
            label9.Name = "label9";
            label9.Size = new Size(183, 20);
            label9.TabIndex = 21;
            label9.Text = "Horário de trabalho:";
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox7.Location = new Point(588, 34);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(162, 23);
            textBox7.TabIndex = 22;
            // 
            // textBox8
            // 
            textBox8.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox8.Location = new Point(588, 77);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(162, 23);
            textBox8.TabIndex = 23;
            // 
            // textBox9
            // 
            textBox9.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox9.Location = new Point(588, 120);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(162, 23);
            textBox9.TabIndex = 24;
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(DataDeNascimento);
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(label16);
            groupBox1.Controls.Add(textBox15);
            groupBox1.Controls.Add(label15);
            groupBox1.Controls.Add(textBox14);
            groupBox1.Controls.Add(label14);
            groupBox1.Controls.Add(textBox13);
            groupBox1.Controls.Add(label13);
            groupBox1.Controls.Add(textBox12);
            groupBox1.Controls.Add(label12);
            groupBox1.Controls.Add(textBox11);
            groupBox1.Controls.Add(label11);
            groupBox1.Controls.Add(label10);
            groupBox1.Controls.Add(button2);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(textBox9);
            groupBox1.Controls.Add(textBox8);
            groupBox1.Controls.Add(textBox7);
            groupBox1.Controls.Add(label9);
            groupBox1.Controls.Add(label8);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(textBox6);
            groupBox1.Controls.Add(textBox5);
            groupBox1.Controls.Add(textBox4);
            groupBox1.Controls.Add(textBox3);
            groupBox1.Controls.Add(textBox2);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label5);
            groupBox1.Controls.Add(label4);
            groupBox1.Controls.Add(label3);
            groupBox1.Controls.Add(label2);
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(12, 27);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(756, 411);
            groupBox1.TabIndex = 7;
            groupBox1.TabStop = false;
            groupBox1.Text = "Cadastro";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // DataDeNascimento
            // 
            DataDeNascimento.CalendarFont = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            DataDeNascimento.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            DataDeNascimento.Location = new Point(221, 158);
            DataDeNascimento.MaxDate = new DateTime(2023, 12, 10, 0, 0, 0, 0);
            DataDeNascimento.MinDate = new DateTime(1900, 1, 1, 0, 0, 0, 0);
            DataDeNascimento.Name = "DataDeNascimento";
            DataDeNascimento.Size = new Size(180, 23);
            DataDeNascimento.TabIndex = 41;
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Masculino", "Feminino" });
            comboBox1.Location = new Point(221, 200);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(180, 24);
            comboBox1.TabIndex = 40;
            // 
            // label16
            // 
            label16.AutoSize = true;
            label16.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label16.Location = new Point(30, 201);
            label16.Name = "label16";
            label16.Size = new Size(139, 20);
            label16.TabIndex = 39;
            label16.Text = "Gênero sexual:";
            // 
            // textBox15
            // 
            textBox15.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox15.Location = new Point(588, 286);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(162, 23);
            textBox15.TabIndex = 38;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(407, 286);
            label15.Name = "label15";
            label15.Size = new Size(67, 20);
            label15.TabIndex = 37;
            label15.Text = "Conta:";
            // 
            // textBox14
            // 
            textBox14.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox14.Location = new Point(588, 239);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(162, 23);
            textBox14.TabIndex = 36;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(407, 239);
            label14.Name = "label14";
            label14.Size = new Size(85, 20);
            label14.TabIndex = 35;
            label14.Text = "Agência:";
            // 
            // textBox13
            // 
            textBox13.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox13.Location = new Point(588, 198);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(52, 23);
            textBox13.TabIndex = 34;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(407, 198);
            label13.Name = "label13";
            label13.Size = new Size(69, 20);
            label13.TabIndex = 33;
            label13.Text = "Banco:";
            // 
            // textBox12
            // 
            textBox12.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox12.Location = new Point(588, 159);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(162, 23);
            textBox12.TabIndex = 32;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(407, 159);
            label12.Name = "label12";
            label12.Size = new Size(162, 20);
            label12.TabIndex = 31;
            label12.Text = "Jornada semanal:";
            // 
            // textBox11
            // 
            textBox11.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox11.Location = new Point(221, 377);
            textBox11.Name = "textBox11";
            textBox11.Size = new Size(180, 23);
            textBox11.TabIndex = 30;
            // 
            // label11
            // 
            label11.AutoSize = true;
            label11.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label11.Location = new Point(30, 380);
            label11.Name = "label11";
            label11.Size = new Size(137, 20);
            label11.TabIndex = 29;
            label11.Text = "Complemento:";
            // 
            // label10
            // 
            label10.AutoSize = true;
            label10.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label10.Location = new Point(30, 158);
            label10.Name = "label10";
            label10.Size = new Size(189, 20);
            label10.TabIndex = 27;
            label10.Text = "Data de nascimento:";
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(634, 335);
            button2.Name = "button2";
            button2.Size = new Size(103, 29);
            button2.TabIndex = 26;
            button2.Text = "Cadastrar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(492, 335);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 25;
            button1.Text = "Voltar";
            button1.UseVisualStyleBackColor = true;
            button1.Click += button1_Click;
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(221, 328);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(180, 23);
            textBox6.TabIndex = 18;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(221, 281);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(180, 23);
            textBox5.TabIndex = 17;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(221, 240);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(180, 23);
            textBox4.TabIndex = 16;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(221, 116);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(180, 23);
            textBox3.TabIndex = 15;
            // 
            // textBox2
            // 
            textBox2.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(221, 74);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(180, 23);
            textBox2.TabIndex = 14;
            textBox2.TextChanged += textBox2_TextChanged;
            // 
            // AddEmpregado
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(groupBox1);
            Name = "AddEmpregado";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Admitir empregado";
            Load += AddEmpregado_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private Label label1;
        private TextBox textBox1;
        private Label label2;
        private Label label3;
        private Label label4;
        private Label label5;
        private Label label6;
        private Label label7;
        private Label label8;
        private Label label9;
        private TextBox textBox7;
        private TextBox textBox8;
        private TextBox textBox9;
        private GroupBox groupBox1;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private TextBox textBox3;
        private TextBox textBox2;
        private Button button2;
        private Button button1;
        private Label label10;
        private TextBox textBox15;
        private Label label15;
        private TextBox textBox14;
        private Label label14;
        private TextBox textBox13;
        private Label label13;
        private TextBox textBox12;
        private Label label12;
        private TextBox textBox11;
        private Label label11;
        private ComboBox comboBox1;
        private Label label16;
        private DateTimePicker DataDeNascimento;
    }
}