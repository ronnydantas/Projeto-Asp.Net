﻿namespace LRSV_pim
{
    partial class ProcessosAdm
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            ListViewItem listViewItem6 = new ListViewItem(new ListViewItem.ListViewSubItem[] { new ListViewItem.ListViewSubItem(null, "Raul Sanches", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "24/10/2023", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Solicito abono de falta, em anexo atestado médico", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Média", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Ponto", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Encerrado", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)) }, -1);
            ListViewItem listViewItem7 = new ListViewItem(new ListViewItem.ListViewSubItem[] { new ListViewItem.ListViewSubItem(null, "Ronny Dantas", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "24/10/2023", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Não consigo entrar no menu de férias", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Alta", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Sistema", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Concluída", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)) }, -1);
            ListViewItem listViewItem8 = new ListViewItem(new ListViewItem.ListViewSubItem[] { new ListViewItem.ListViewSubItem(null, "Lucas Tolentino", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "24/10/2023", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Meu salário caiu com desonto indevido", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Crítica", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Folha de pagamento", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Em andamento", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)) }, -1);
            ListViewItem listViewItem9 = new ListViewItem(new ListViewItem.ListViewSubItem[] { new ListViewItem.ListViewSubItem(null, "Rafael O. Gomes", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "24/10/2023", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Vale-refeição caiu valor a menos", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Alta", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Benefícios", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Em andamento", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)) }, -1);
            ListViewItem listViewItem10 = new ListViewItem(new ListViewItem.ListViewSubItem[] { new ListViewItem.ListViewSubItem(null, "Vinicius Bezerra", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "24/10/2023", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Plano de saúde está inativo indevidamente", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Crítica", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Benefícios", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)), new ListViewItem.ListViewSubItem(null, "Encerrado", SystemColors.WindowText, SystemColors.Window, new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point)) }, -1);
            groupBox1 = new GroupBox();
            comboBox1 = new ComboBox();
            comboBox2 = new ComboBox();
            label6 = new Label();
            label7 = new Label();
            DataDeNascimento = new DateTimePicker();
            button1 = new Button();
            label1 = new Label();
            listView1 = new ListView();
            columnHeader1 = new ColumnHeader();
            columnHeader2 = new ColumnHeader();
            columnHeader3 = new ColumnHeader();
            columnHeader4 = new ColumnHeader();
            columnHeader5 = new ColumnHeader();
            columnHeader6 = new ColumnHeader();
            button2 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(comboBox1);
            groupBox1.Controls.Add(comboBox2);
            groupBox1.Controls.Add(label6);
            groupBox1.Controls.Add(label7);
            groupBox1.Controls.Add(DataDeNascimento);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(29, 12);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(729, 212);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Selecione a data desejada para filtrar todos os chamados de funcionários, e escolha a categoria e prioridade. Logo após clique em \"Filtrar\".";
            // 
            // comboBox1
            // 
            comboBox1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox1.FormattingEnabled = true;
            comboBox1.Items.AddRange(new object[] { "Todos", "Ponto", "Sistema", "Folha de pagamento", "Benefícios" });
            comboBox1.Location = new Point(130, 134);
            comboBox1.Name = "comboBox1";
            comboBox1.Size = new Size(198, 28);
            comboBox1.TabIndex = 46;
            // 
            // comboBox2
            // 
            comboBox2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            comboBox2.FormattingEnabled = true;
            comboBox2.Items.AddRange(new object[] { "Todos", "Baixa", "Média", "Alta", "Crítica" });
            comboBox2.Location = new Point(130, 94);
            comboBox2.Name = "comboBox2";
            comboBox2.Size = new Size(198, 28);
            comboBox2.TabIndex = 45;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(10, 134);
            label6.Name = "label6";
            label6.Size = new Size(99, 20);
            label6.TabIndex = 44;
            label6.Text = "Categoria:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(6, 97);
            label7.Name = "label7";
            label7.Size = new Size(103, 20);
            label7.TabIndex = 43;
            label7.Text = "Prioridade:";
            // 
            // DataDeNascimento
            // 
            DataDeNascimento.CalendarFont = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            DataDeNascimento.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            DataDeNascimento.Location = new Point(130, 57);
            DataDeNascimento.MaxDate = new DateTime(2023, 12, 10, 0, 0, 0, 0);
            DataDeNascimento.MinDate = new DateTime(1900, 1, 1, 0, 0, 0, 0);
            DataDeNascimento.Name = "DataDeNascimento";
            DataDeNascimento.Size = new Size(320, 23);
            DataDeNascimento.TabIndex = 42;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(616, 171);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Filtrar";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(6, 57);
            label1.Name = "label1";
            label1.Size = new Size(57, 20);
            label1.TabIndex = 3;
            label1.Text = "Data:";
            // 
            // listView1
            // 
            listView1.Columns.AddRange(new ColumnHeader[] { columnHeader1, columnHeader2, columnHeader3, columnHeader4, columnHeader5, columnHeader6 });
            listViewItem6.StateImageIndex = 0;
            listView1.Items.AddRange(new ListViewItem[] { listViewItem6, listViewItem7, listViewItem8, listViewItem9, listViewItem10 });
            listView1.Location = new Point(29, 230);
            listView1.Name = "listView1";
            listView1.Size = new Size(729, 161);
            listView1.TabIndex = 6;
            listView1.UseCompatibleStateImageBehavior = false;
            listView1.View = View.Details;
            // 
            // columnHeader1
            // 
            columnHeader1.Text = "Usuário";
            columnHeader1.Width = 80;
            // 
            // columnHeader2
            // 
            columnHeader2.Text = "Data";
            columnHeader2.TextAlign = HorizontalAlignment.Center;
            columnHeader2.Width = 90;
            // 
            // columnHeader3
            // 
            columnHeader3.Text = "Resumo";
            columnHeader3.TextAlign = HorizontalAlignment.Center;
            columnHeader3.Width = 270;
            // 
            // columnHeader4
            // 
            columnHeader4.Text = "Prioridade";
            columnHeader4.TextAlign = HorizontalAlignment.Center;
            columnHeader4.Width = 100;
            // 
            // columnHeader5
            // 
            columnHeader5.Text = "Categoria";
            columnHeader5.TextAlign = HorizontalAlignment.Center;
            columnHeader5.Width = 100;
            // 
            // columnHeader6
            // 
            columnHeader6.Text = "Status";
            columnHeader6.TextAlign = HorizontalAlignment.Center;
            columnHeader6.Width = 100;
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(29, 410);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 47;
            button2.Text = "Voltar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // ProcessosAdm
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button2);
            Controls.Add(listView1);
            Controls.Add(groupBox1);
            Name = "ProcessosAdm";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Chamados de colaboradores";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
        }

        #endregion

        private GroupBox groupBox1;
        private Button button1;
        private Label label1;
        private DateTimePicker DataDeNascimento;
        private Label label7;
        private Label label6;
        private ComboBox comboBox2;
        private ComboBox comboBox1;
        private ListView listView1;
        private ColumnHeader columnHeader1;
        private ColumnHeader columnHeader2;
        private ColumnHeader columnHeader3;
        private ColumnHeader columnHeader4;
        private ColumnHeader columnHeader5;
        private ColumnHeader columnHeader6;
        private Button button2;
    }
}