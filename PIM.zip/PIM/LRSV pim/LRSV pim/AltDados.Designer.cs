﻿namespace LRSV_pim
{
    partial class AltDados
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            button2 = new Button();
            textBox2 = new TextBox();
            label2 = new Label();
            textBox15 = new TextBox();
            label15 = new Label();
            textBox14 = new TextBox();
            label14 = new Label();
            textBox13 = new TextBox();
            label13 = new Label();
            textBox12 = new TextBox();
            label12 = new Label();
            textBox9 = new TextBox();
            textBox8 = new TextBox();
            textBox7 = new TextBox();
            label9 = new Label();
            label8 = new Label();
            label7 = new Label();
            textBox6 = new TextBox();
            textBox5 = new TextBox();
            textBox4 = new TextBox();
            label6 = new Label();
            label5 = new Label();
            label4 = new Label();
            button3 = new Button();
            groupBox1.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(30, 21);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(729, 167);
            groupBox1.TabIndex = 3;
            groupBox1.TabStop = false;
            groupBox1.Text = "Digite o CPF do colaborador que deseja realizar a alteração de dados, logo após clique em \"Buscar\" para realizar a pesquisa no banco de dados.";
            groupBox1.Enter += groupBox1_Enter;
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(88, 79);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(257, 23);
            textBox1.TabIndex = 5;
            textBox1.TextChanged += textBox1_TextChanged;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(607, 120);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(11, 78);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 3;
            label1.Text = "CPF:";
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(30, 456);
            button2.Name = "button2";
            button2.Size = new Size(94, 29);
            button2.TabIndex = 6;
            button2.Text = "Voltar";
            button2.UseVisualStyleBackColor = true;
            button2.Click += button2_Click;
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Menu;
            textBox2.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(195, 211);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(180, 23);
            textBox2.TabIndex = 10;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(36, 210);
            label2.Name = "label2";
            label2.Size = new Size(152, 20);
            label2.TabIndex = 9;
            label2.Text = "Nome completo:";
            // 
            // textBox15
            // 
            textBox15.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox15.Location = new Point(588, 389);
            textBox15.Name = "textBox15";
            textBox15.Size = new Size(162, 23);
            textBox15.TabIndex = 58;
            // 
            // label15
            // 
            label15.AutoSize = true;
            label15.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label15.Location = new Point(512, 388);
            label15.Name = "label15";
            label15.Size = new Size(67, 20);
            label15.TabIndex = 57;
            label15.Text = "Conta:";
            // 
            // textBox14
            // 
            textBox14.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox14.Location = new Point(381, 385);
            textBox14.Name = "textBox14";
            textBox14.Size = new Size(102, 23);
            textBox14.TabIndex = 56;
            // 
            // label14
            // 
            label14.AutoSize = true;
            label14.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label14.Location = new Point(290, 384);
            label14.Name = "label14";
            label14.Size = new Size(85, 20);
            label14.TabIndex = 55;
            label14.Text = "Agência:";
            // 
            // textBox13
            // 
            textBox13.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox13.Location = new Point(195, 381);
            textBox13.Name = "textBox13";
            textBox13.Size = new Size(60, 23);
            textBox13.TabIndex = 54;
            // 
            // label13
            // 
            label13.AutoSize = true;
            label13.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label13.Location = new Point(36, 380);
            label13.Name = "label13";
            label13.Size = new Size(69, 20);
            label13.TabIndex = 53;
            label13.Text = "Banco:";
            // 
            // textBox12
            // 
            textBox12.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox12.Location = new Point(588, 336);
            textBox12.Name = "textBox12";
            textBox12.Size = new Size(162, 23);
            textBox12.TabIndex = 52;
            // 
            // label12
            // 
            label12.AutoSize = true;
            label12.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label12.Location = new Point(407, 336);
            label12.Name = "label12";
            label12.Size = new Size(162, 20);
            label12.TabIndex = 51;
            label12.Text = "Jornada semanal:";
            // 
            // textBox9
            // 
            textBox9.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox9.Location = new Point(588, 297);
            textBox9.Name = "textBox9";
            textBox9.Size = new Size(162, 23);
            textBox9.TabIndex = 50;
            // 
            // textBox8
            // 
            textBox8.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox8.Location = new Point(588, 254);
            textBox8.Name = "textBox8";
            textBox8.Size = new Size(162, 23);
            textBox8.TabIndex = 49;
            // 
            // textBox7
            // 
            textBox7.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox7.Location = new Point(588, 211);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(162, 23);
            textBox7.TabIndex = 48;
            // 
            // label9
            // 
            label9.AutoSize = true;
            label9.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label9.Location = new Point(407, 297);
            label9.Name = "label9";
            label9.Size = new Size(183, 20);
            label9.TabIndex = 47;
            label9.Text = "Horário de trabalho:";
            // 
            // label8
            // 
            label8.AutoSize = true;
            label8.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label8.Location = new Point(407, 254);
            label8.Name = "label8";
            label8.Size = new Size(76, 20);
            label8.TabIndex = 46;
            label8.Text = "Salário:";
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(407, 214);
            label7.Name = "label7";
            label7.Size = new Size(67, 20);
            label7.TabIndex = 45;
            label7.Text = "Cargo:";
            // 
            // textBox6
            // 
            textBox6.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox6.Location = new Point(195, 342);
            textBox6.Name = "textBox6";
            textBox6.Size = new Size(180, 23);
            textBox6.TabIndex = 44;
            // 
            // textBox5
            // 
            textBox5.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox5.Location = new Point(195, 293);
            textBox5.Name = "textBox5";
            textBox5.Size = new Size(180, 23);
            textBox5.TabIndex = 43;
            // 
            // textBox4
            // 
            textBox4.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox4.Location = new Point(195, 253);
            textBox4.Name = "textBox4";
            textBox4.Size = new Size(180, 23);
            textBox4.TabIndex = 42;
            // 
            // label6
            // 
            label6.AutoSize = true;
            label6.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label6.Location = new Point(36, 341);
            label6.Name = "label6";
            label6.Size = new Size(96, 20);
            label6.TabIndex = 41;
            label6.Text = "Endereço:";
            // 
            // label5
            // 
            label5.AutoSize = true;
            label5.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label5.Location = new Point(36, 296);
            label5.Name = "label5";
            label5.Size = new Size(73, 20);
            label5.TabIndex = 40;
            label5.Text = "E-mail:";
            // 
            // label4
            // 
            label4.AutoSize = true;
            label4.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label4.Location = new Point(36, 253);
            label4.Name = "label4";
            label4.Size = new Size(87, 20);
            label4.TabIndex = 39;
            label4.Text = "Telefone:";
            // 
            // button3
            // 
            button3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button3.Location = new Point(637, 456);
            button3.Name = "button3";
            button3.Size = new Size(113, 29);
            button3.TabIndex = 59;
            button3.Text = "Alterar";
            button3.UseVisualStyleBackColor = true;
            // 
            // AltDados
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 507);
            Controls.Add(button3);
            Controls.Add(textBox15);
            Controls.Add(label15);
            Controls.Add(textBox14);
            Controls.Add(label14);
            Controls.Add(textBox13);
            Controls.Add(label13);
            Controls.Add(textBox12);
            Controls.Add(label12);
            Controls.Add(textBox9);
            Controls.Add(textBox8);
            Controls.Add(textBox7);
            Controls.Add(label9);
            Controls.Add(label8);
            Controls.Add(label7);
            Controls.Add(textBox6);
            Controls.Add(textBox5);
            Controls.Add(textBox4);
            Controls.Add(label6);
            Controls.Add(label5);
            Controls.Add(label4);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(button2);
            Controls.Add(groupBox1);
            Name = "AltDados";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Alterar dados";
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox1;
        private Button button1;
        private Label label1;
        private Button button2;
        private TextBox textBox2;
        private Label label2;
        private TextBox textBox15;
        private Label label15;
        private TextBox textBox14;
        private Label label14;
        private TextBox textBox13;
        private Label label13;
        private TextBox textBox12;
        private Label label12;
        private TextBox textBox9;
        private TextBox textBox8;
        private TextBox textBox7;
        private Label label9;
        private Label label8;
        private Label label7;
        private TextBox textBox6;
        private TextBox textBox5;
        private TextBox textBox4;
        private Label label6;
        private Label label5;
        private Label label4;
        private Button button3;
    }
}