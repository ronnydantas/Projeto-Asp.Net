﻿namespace LRSV_pim
{
    partial class PagAdc
    {
        /// <summary>
        /// Required designer variable.
        /// </summary>
        private System.ComponentModel.IContainer components = null;

        /// <summary>
        /// Clean up any resources being used.
        /// </summary>
        /// <param name="disposing">true if managed resources should be disposed; otherwise, false.</param>
        protected override void Dispose(bool disposing)
        {
            if (disposing && (components != null))
            {
                components.Dispose();
            }
            base.Dispose(disposing);
        }

        #region Windows Form Designer generated code

        /// <summary>
        /// Required method for Designer support - do not modify
        /// the contents of this method with the code editor.
        /// </summary>
        private void InitializeComponent()
        {
            groupBox1 = new GroupBox();
            textBox1 = new TextBox();
            button1 = new Button();
            label1 = new Label();
            textBox7 = new TextBox();
            label7 = new Label();
            textBox2 = new TextBox();
            label2 = new Label();
            groupBox2 = new GroupBox();
            button2 = new Button();
            textBox3 = new TextBox();
            label3 = new Label();
            button7 = new Button();
            groupBox1.SuspendLayout();
            groupBox2.SuspendLayout();
            SuspendLayout();
            // 
            // groupBox1
            // 
            groupBox1.Controls.Add(textBox1);
            groupBox1.Controls.Add(button1);
            groupBox1.Controls.Add(label1);
            groupBox1.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox1.Location = new Point(28, 27);
            groupBox1.Name = "groupBox1";
            groupBox1.Size = new Size(740, 167);
            groupBox1.TabIndex = 5;
            groupBox1.TabStop = false;
            groupBox1.Text = "Digite o CPF do colaborador que deseja realizar a inclusão de pagamentos adicionais, logo após clique em \"Buscar\" para realizar a pesquisa no banco de dados.";
            // 
            // textBox1
            // 
            textBox1.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox1.Location = new Point(88, 79);
            textBox1.Name = "textBox1";
            textBox1.Size = new Size(257, 23);
            textBox1.TabIndex = 5;
            // 
            // button1
            // 
            button1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button1.Location = new Point(607, 120);
            button1.Name = "button1";
            button1.Size = new Size(94, 29);
            button1.TabIndex = 4;
            button1.Text = "Buscar";
            button1.UseVisualStyleBackColor = true;
            // 
            // label1
            // 
            label1.AutoSize = true;
            label1.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label1.Location = new Point(11, 78);
            label1.Name = "label1";
            label1.Size = new Size(49, 20);
            label1.TabIndex = 3;
            label1.Text = "CPF:";
            // 
            // textBox7
            // 
            textBox7.BackColor = SystemColors.Menu;
            textBox7.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox7.Location = new Point(580, 214);
            textBox7.Name = "textBox7";
            textBox7.Size = new Size(188, 23);
            textBox7.TabIndex = 56;
            // 
            // label7
            // 
            label7.AutoSize = true;
            label7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label7.Location = new Point(491, 214);
            label7.Name = "label7";
            label7.Size = new Size(67, 20);
            label7.TabIndex = 55;
            label7.Text = "Cargo:";
            // 
            // textBox2
            // 
            textBox2.BackColor = SystemColors.Menu;
            textBox2.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox2.Location = new Point(187, 214);
            textBox2.Name = "textBox2";
            textBox2.Size = new Size(180, 23);
            textBox2.TabIndex = 54;
            // 
            // label2
            // 
            label2.AutoSize = true;
            label2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label2.Location = new Point(28, 213);
            label2.Name = "label2";
            label2.Size = new Size(152, 20);
            label2.TabIndex = 53;
            label2.Text = "Nome completo:";
            // 
            // groupBox2
            // 
            groupBox2.Controls.Add(button2);
            groupBox2.Controls.Add(textBox3);
            groupBox2.Controls.Add(label3);
            groupBox2.Font = new Font("Verdana", 10.2F, FontStyle.Bold, GraphicsUnit.Point);
            groupBox2.Location = new Point(28, 282);
            groupBox2.Name = "groupBox2";
            groupBox2.Size = new Size(740, 103);
            groupBox2.TabIndex = 6;
            groupBox2.TabStop = false;
            groupBox2.Text = "Bonificação";
            // 
            // button2
            // 
            button2.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button2.Location = new Point(499, 49);
            button2.Name = "button2";
            button2.Size = new Size(202, 29);
            button2.TabIndex = 8;
            button2.Text = "Incluir ao funcionário";
            button2.UseVisualStyleBackColor = true;
            // 
            // textBox3
            // 
            textBox3.Font = new Font("Verdana", 7.8F, FontStyle.Regular, GraphicsUnit.Point);
            textBox3.Location = new Point(106, 48);
            textBox3.Name = "textBox3";
            textBox3.Size = new Size(87, 23);
            textBox3.TabIndex = 10;
            // 
            // label3
            // 
            label3.AutoSize = true;
            label3.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            label3.Location = new Point(11, 48);
            label3.Name = "label3";
            label3.Size = new Size(89, 20);
            label3.TabIndex = 9;
            label3.Text = "Valor: R$";
            // 
            // button7
            // 
            button7.Font = new Font("Verdana", 10.2F, FontStyle.Regular, GraphicsUnit.Point);
            button7.Location = new Point(28, 409);
            button7.Name = "button7";
            button7.Size = new Size(94, 29);
            button7.TabIndex = 66;
            button7.Text = "Voltar";
            button7.UseVisualStyleBackColor = true;
            // 
            // PagAdc
            // 
            AutoScaleDimensions = new SizeF(8F, 20F);
            AutoScaleMode = AutoScaleMode.Font;
            ClientSize = new Size(800, 450);
            Controls.Add(button7);
            Controls.Add(groupBox2);
            Controls.Add(textBox7);
            Controls.Add(label7);
            Controls.Add(textBox2);
            Controls.Add(label2);
            Controls.Add(groupBox1);
            Name = "PagAdc";
            StartPosition = FormStartPosition.CenterScreen;
            Text = "Pagamentos adicionais";
            Load += PagAdc_Load;
            groupBox1.ResumeLayout(false);
            groupBox1.PerformLayout();
            groupBox2.ResumeLayout(false);
            groupBox2.PerformLayout();
            ResumeLayout(false);
            PerformLayout();
        }

        #endregion

        private GroupBox groupBox1;
        private TextBox textBox1;
        private Button button1;
        private Label label1;
        private TextBox textBox7;
        private Label label7;
        private TextBox textBox2;
        private Label label2;
        private GroupBox groupBox2;
        private Button button2;
        private TextBox textBox3;
        private Label label3;
        private Button button7;
    }
}